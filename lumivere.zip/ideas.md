# LUMIVÈRE — Design Brainstorm

## Three Stylistic Approaches

### 1. Parisian Atelier Romantique
A hushed, editorial world of ivory walls, pressed botanicals, and candlelight. Inspired by the quiet luxury of a Parisian flower shop at dusk.
**Probability:** 0.07

### 2. Sculptural Minimalism
Cool, gallery-white spaces with dramatic negative space. Each product treated as a sculptural object on a plinth. Inspired by Loewe's editorial restraint.
**Probability:** 0.04

### 3. Velvet Boudoir Editorial
Rich, moody warmth — dusty rose, deep burgundy, champagne gold. Like the pages of a luxury fashion magazine crossed with a candlelit boudoir.
**Probability:** 0.08

---

## ✦ Chosen Approach: Parisian Atelier Romantique

### Design Movement
**Romantic Modernism** — the visual language of a Parisian haute-couture atelier translated to digital. Think Dior Maison lookbooks, Diptyque editorial campaigns, and the tactile warmth of handmade luxury objects. Quiet, unhurried, deeply feminine.

### Core Principles
1. **Restraint as luxury** — every element earns its place; whitespace is the primary material
2. **Tactile warmth** — soft gradients, parchment textures, and candlelight-inspired color temperature
3. **Editorial rhythm** — asymmetric layouts, oversized type moments, and cinematic photography framing
4. **Slow beauty** — animations are slow, deliberate, and breath-like; nothing snaps or bounces

### Color Philosophy
The palette is drawn from a Parisian morning: ivory light through linen curtains, blush roses in a ceramic vase, a champagne flute catching the sun. Colors are warm, muted, and layered — never flat.

| Token | Value | Emotion |
|---|---|---|
| Ivory | `oklch(0.975 0.008 85)` | Purity, light, parchment |
| Blush | `oklch(0.88 0.04 10)` | Femininity, romance, petals |
| Champagne | `oklch(0.82 0.06 80)` | Luxury, warmth, gold |
| Warm Beige | `oklch(0.92 0.018 75)` | Comfort, naturalness |
| Dusty Rose | `oklch(0.72 0.07 12)` | Depth, sophistication |
| Burgundy | `oklch(0.38 0.12 15)` | Drama, richness, accent |
| Deep Charcoal | `oklch(0.22 0.01 60)` | Elegance, text, grounding |

### Layout Paradigm
**Asymmetric editorial flow** — sections alternate between left-heavy and right-heavy compositions. Product photography bleeds to the edge on one side while text floats with generous margins on the other. The grid is felt but never rigid. Hero sections are full-bleed. Product cards use staggered heights.

### Signature Elements
1. **Thin gold rule lines** — 1px champagne-gold horizontal rules used as section dividers and decorative accents
2. **Oversized serif numerals** — large, ghost-opacity numbers (01, 02, 03) anchoring collection sections
3. **Floating petal motifs** — subtle CSS-animated rose petals drifting across the hero and select sections

### Interaction Philosophy
Interactions feel like turning pages in a luxury lookbook. Hover states reveal information gently — no sudden jumps. Buttons use a slow fill animation. Product cards lift with a whisper of shadow. The cursor itself feels intentional.

### Animation
- **Entrance:** Elements fade in with `opacity: 0 → 1` + `translateY(24px → 0)` over `800ms cubic-bezier(0.23, 1, 0.32, 1)`
- **Stagger:** Grouped items stagger by `80ms` per element
- **Hero petals:** Infinite float animation, `20–40s` duration, random drift paths, `opacity: 0.3–0.6`
- **Button hover:** Background fills from left over `400ms ease-out`; text color transitions simultaneously
- **Image hover:** Scale `1.0 → 1.04` over `600ms ease-out`; no abrupt jumps
- **Scroll-triggered:** IntersectionObserver triggers entrance animations at `threshold: 0.15`
- **Page transitions:** Fade in/out `300ms`
- **Reduced motion:** All non-essential animations gated behind `prefers-reduced-motion: no-preference`

### Typography System
- **Display / Headlines:** `Cormorant Garamond` — Italic weight for hero; Regular for section titles. Sizes: 72–96px hero, 48–64px section, 32–40px subsection.
- **Subheadings / Labels:** `Cormorant Garamond` Regular, tracked at `0.15em`, small caps treatment for category labels
- **Body / UI:** `Jost` — Light (300) for body text, Regular (400) for UI labels, Medium (500) for buttons and navigation
- **Accent / Micro:** `Jost` Light, `0.12em` letter-spacing, uppercase for tags and metadata

### Brand Essence
*The world's most beautiful candles — for women who collect beauty, not just objects.*
**Personality:** Poetic · Refined · Intimate

### Brand Voice
Headlines and CTAs speak in whispers, not shouts. Sentences are short, evocative, and sensory. French words and phrases appear sparingly as authentic texture — never pastiche.

Example lines:
- *"Light one. The room remembers."*
- *"Not a candle. A conversation piece."*

**Banned phrases:** "Welcome to our website", "Get started today", "Shop now" (use "Discover the Collection" instead), "Add to cart" (use "Reserve" or "Add to Atelier")

### Wordmark & Logo
A stylized fleur-de-lis abstracted into a single petal drop — the letter "L" transformed into a falling rose petal. Rendered in champagne gold on ivory backgrounds, ivory on dark backgrounds.

### Signature Brand Color
**Champagne Gold** — `oklch(0.82 0.06 80)` — the color of candlelight on ivory wax. Unmistakably LUMIVÈRE.

---

## Style Decisions
- Navigation uses a transparent-to-ivory scroll transition with a thin gold underline on active links
- Product cards use a portrait-format (3:4) aspect ratio to evoke editorial photography
- All CTAs use the word "Discover" or "Explore" — never generic imperatives
- Section numbers use Cormorant Garamond at 120px, 5% opacity, as decorative anchors
- Footer uses deep charcoal background with ivory text and champagne gold accents

---

## Style Decisions

*Applied from trusted style review — June 2026*

1. **Commerce pages follow the same asymmetric editorial rhythm as storytelling pages.** Product grids are staggered and curated, never a uniform catalog wall. The first product in any collection/shop page is always featured large (5/12 columns) with the rest in a standard grid.

2. **Mandatory recurring brand motifs across every major page:** oversized Cormorant Garamond numerals (01, 02, 03) as section anchors, champagne gold rule lines, and the ✦ petal-drop symbol as a recurring decorative element.

3. **CTAs use only poetic maison language:** "Discover," "Explore," "Reserve," "Add to Atelier," "Receive the Letters," "Explore the Atelier." Generic shopping language ("Shop the Collection," "Buy Now," "Add to Cart") is banned throughout the site.

4. **The LUMIVÈRE wordmark is always present at a clearly visible size** — minimum 10px logo mark + 24px display type in the header and footer. Never tiny.

5. **Product photography is treated as art direction.** Each product image should feel individually photographed and curated. Repeated images across multiple product cards weaken the luxury illusion.
