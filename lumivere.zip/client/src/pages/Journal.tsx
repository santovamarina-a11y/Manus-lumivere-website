/* LUMIVÈRE Journal Page */

import { useState } from 'react';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';
import { useRevealOnMount } from '@/hooks/useScrollReveal';

const articles = [
  {
    id: 'art-of-candle-care',
    category: 'Candle Care',
    title: 'The Art of the First Burn',
    subtitle: 'Why the first hour determines everything',
    excerpt: 'There is a ritual to lighting a new candle for the first time. It is not merely a matter of striking a match. It is the beginning of a relationship.',
    date: 'December 12, 2024',
    readTime: '4 min read',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-peony-YipPMMyqLkerp7Skc6EcHb.webp',
    featured: true,
  },
  {
    id: 'zodiac-gifting',
    category: 'Gifting',
    title: 'The Perfect Gift for Every Sign',
    subtitle: 'A guide to zodiac candle gifting',
    excerpt: 'A gift that knows someone\'s star sign says something profound: I paid attention. Here is how to choose the right LUMIVÈRE zodiac candle for the people you love.',
    date: 'November 28, 2024',
    readTime: '6 min read',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
    featured: false,
  },
  {
    id: 'paris-atelier',
    category: 'Behind the Scenes',
    title: 'A Day in the Atelier',
    subtitle: 'How a LUMIVÈRE candle is born',
    excerpt: 'The atelier smells of warm wax and jasmine at 7am. Élise is already at her bench, a half-finished peony in her hands. This is where every LUMIVÈRE candle begins.',
    date: 'November 10, 2024',
    readTime: '8 min read',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-atelier-PvYdNxmoxk9cUa3cf78pNb.webp',
    featured: false,
  },
  {
    id: 'scent-memory',
    category: 'Fragrance',
    title: 'Why Scent is the Strongest Memory',
    subtitle: 'The neuroscience of fragrance and emotion',
    excerpt: 'Of all the senses, smell is the most direct route to memory. A single breath of rose absolute can return you to a garden you visited twenty years ago.',
    date: 'October 22, 2024',
    readTime: '5 min read',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-rose-h5kGVBJnRx8n9jprE2AyMu.webp',
    featured: false,
  },
  {
    id: 'autumn-collection',
    category: 'Collections',
    title: 'Introducing Automne Doré',
    subtitle: 'Our most dramatic seasonal collection yet',
    excerpt: 'Autumn is the season of beautiful endings. The Automne Doré collection captures that bittersweet perfection — three flowers at the height of their last bloom.',
    date: 'October 1, 2024',
    readTime: '3 min read',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-seasonal-NbE5FZrZFzdqPD2644veLD.webp',
    featured: false,
  },
];

const categories = ['All', 'Candle Care', 'Gifting', 'Behind the Scenes', 'Fragrance', 'Collections'];

export default function Journal() {
  const [activeCategory, setActiveCategory] = useState('All');
  useRevealOnMount([activeCategory]);

  const featured = articles.find(a => a.featured);
  const filtered = articles
    .filter(a => !a.featured)
    .filter(a => activeCategory === 'All' || a.category === activeCategory);

  return (
    <div className="min-h-screen bg-ivory pt-20">
      {/* Header */}
      <div className="py-20 text-center" style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}>
        <p className="text-label text-gold mb-4">Le Journal</p>
        <h1 className="text-section-title text-charcoal">Stories from the Atelier</h1>
        <div className="flex items-center justify-center gap-4 mt-6">
          <div className="gold-rule-short" />
          <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '8px' }}>✦</span>
          <div className="gold-rule-short" />
        </div>
        <p className="font-body font-light text-muted-foreground mt-4 max-w-md mx-auto">
          On candle care, fragrance, gifting, and the art of living beautifully.
        </p>
      </div>

      {/* Featured Article */}
      {featured && (
        <div className="container py-16">
          <div className="reveal">
            <p className="text-label text-gold mb-8">Featured Story</p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center reveal">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={featured.image}
                alt={featured.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              />
            </div>
            <div>
              <p className="text-label text-gold mb-4">{featured.category}</p>
              <h2 className="font-display text-4xl md:text-5xl text-charcoal mb-3" style={{ fontStyle: 'italic', fontWeight: 300 }}>
                {featured.title}
              </h2>
              <p className="font-display text-xl text-dusty-rose mb-6" style={{ fontStyle: 'italic' }}>{featured.subtitle}</p>
              <p className="font-body font-light text-charcoal/70 leading-relaxed mb-8">{featured.excerpt}</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-label text-muted-foreground">{featured.date}</p>
                  <p className="text-label text-muted-foreground">{featured.readTime}</p>
                </div>
                <button className="btn-luxury-outline">
                  <span>Read Article</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Category Filter */}
      <div className="container border-t border-border py-8">
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className="text-label px-4 py-2 border transition-all duration-300"
              style={{
                borderColor: activeCategory === cat ? 'oklch(0.75 0.10 82)' : 'oklch(0.88 0.015 75)',
                backgroundColor: activeCategory === cat ? 'oklch(0.22 0.01 60)' : 'transparent',
                color: activeCategory === cat ? 'oklch(0.975 0.008 85)' : 'oklch(0.55 0.02 60)',
              }}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Articles Grid */}
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-12">
          {filtered.map((article, i) => (
            <article key={article.id} className={`group cursor-pointer reveal`} style={{ transitionDelay: `${i * 100}ms` }}>
              <div className="aspect-[4/3] overflow-hidden mb-6">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <p className="text-label text-gold mb-2">{article.category}</p>
              <h3 className="font-display text-2xl md:text-3xl text-charcoal mb-2 group-hover:text-dusty-rose transition-colors duration-300" style={{ fontStyle: 'italic' }}>
                {article.title}
              </h3>
              <p className="font-display text-lg text-muted-foreground mb-4" style={{ fontStyle: 'italic' }}>{article.subtitle}</p>
              <p className="font-body font-light text-charcoal/65 leading-relaxed mb-6 text-sm">{article.excerpt}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="text-label text-muted-foreground">{article.date}</span>
                  <span className="text-label text-muted-foreground">·</span>
                  <span className="text-label text-muted-foreground">{article.readTime}</span>
                </div>
                <div className="flex items-center gap-2 text-charcoal group-hover:text-gold transition-colors duration-300">
                  <span className="text-label">Read</span>
                  <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Newsletter CTA */}
      <div className="container py-16 border-t border-border">
        <div className="text-center reveal">
          <p className="text-label text-gold mb-4">La Lettre de l'Atelier</p>
          <h2 className="font-display text-3xl text-charcoal mb-6" style={{ fontStyle: 'italic' }}>
            Letters from the Atelier
          </h2>
          <p className="font-body font-light text-muted-foreground mb-8 max-w-md mx-auto">
            New articles, seasonal collections, and exclusive offers — delivered with care.
          </p>
          <Link href="/#newsletter">
            <button className="btn-luxury">
              <span>Receive the Letters</span>
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
