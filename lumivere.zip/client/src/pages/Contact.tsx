/* LUMIVÈRE Contact Page */

import { useState } from 'react';
import { MapPin, Mail, Clock, Gift } from 'lucide-react';
import { useRevealOnMount } from '@/hooks/useScrollReveal';

const faqs = [
  {
    q: 'How long do LUMIVÈRE candles burn?',
    a: 'Burn times vary by size. Our small candles (200g) burn for 25–35 hours. Grande (400g) burn for 35–55 hours. Our signature bouquet candles burn for 60–80 hours with proper care.',
  },
  {
    q: 'Can I customise a candle for a special occasion?',
    a: 'Yes. We offer bespoke candles for weddings, corporate gifts, and special events. Please contact us at least 6 weeks in advance. Minimum order of 10 pieces for bespoke commissions.',
  },
  {
    q: 'Do you ship internationally?',
    a: 'We ship to over 40 countries. International shipping times vary from 3–10 business days. All orders are carefully packaged to protect your candle during transit.',
  },
  {
    q: 'What is your return policy?',
    a: 'We accept returns within 14 days for unopened, unused items in their original packaging. Due to the handcrafted nature of our products, we cannot accept returns on lit candles.',
  },
  {
    q: 'Are your candles safe for people with allergies?',
    a: 'Our candles are made with 100% natural soy wax and botanical fragrances. We recommend checking the fragrance notes if you have known allergies to specific botanicals. Unscented options are available for all products.',
  },
];

export default function Contact() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  useRevealOnMount([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-ivory pt-20">
      {/* Header */}
      <div className="py-20 text-center" style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}>
        <p className="text-label text-gold mb-4">Nous Contacter</p>
        <h1 className="text-section-title text-charcoal">Get in Touch</h1>
        <div className="flex items-center justify-center gap-4 mt-6">
          <div className="gold-rule-short" />
          <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '8px' }}>✦</span>
          <div className="gold-rule-short" />
        </div>
        <p className="font-body font-light text-muted-foreground mt-4 max-w-md mx-auto">
          We respond to every message personally. No automated replies. Just people who care.
        </p>
      </div>

      <div className="container py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Contact Form */}
          <div className="reveal">
            <h2 className="font-display text-3xl text-charcoal mb-8" style={{ fontStyle: 'italic' }}>Send a Message</h2>

            {submitted ? (
              <div className="text-center py-16">
                <div className="flex items-center justify-center gap-4 mb-6">
                  <div className="gold-rule-short" />
                  <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '12px' }}>✦</span>
                  <div className="gold-rule-short" />
                </div>
                <p className="font-display text-3xl text-charcoal italic mb-4">Merci.</p>
                <p className="font-body font-light text-muted-foreground">
                  Your message has been received. We will reply within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <label className="text-label text-muted-foreground block mb-2">Your Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="input-luxury"
                      placeholder="Élise Moreau"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-label text-muted-foreground block mb-2">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="input-luxury"
                      placeholder="elise@example.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-label text-muted-foreground block mb-2">Subject</label>
                  <select
                    value={formData.subject}
                    onChange={e => setFormData({ ...formData, subject: e.target.value })}
                    className="input-luxury"
                    required
                  >
                    <option value="">Select a subject</option>
                    <option value="order">Order Enquiry</option>
                    <option value="gifting">Corporate Gifting</option>
                    <option value="bespoke">Bespoke Commission</option>
                    <option value="press">Press & Collaboration</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-label text-muted-foreground block mb-2">Your Message</label>
                  <textarea
                    value={formData.message}
                    onChange={e => setFormData({ ...formData, message: e.target.value })}
                    className="input-luxury resize-none"
                    placeholder="Tell us how we can help..."
                    rows={6}
                    required
                  />
                </div>

                <button type="submit" className="btn-luxury">
                  <span>Send Message</span>
                </button>
              </form>
            )}
          </div>

          {/* Contact Info */}
          <div className="space-y-12 reveal reveal-delay-2">
            <div>
              <h2 className="font-display text-3xl text-charcoal mb-8" style={{ fontStyle: 'italic' }}>Find Us</h2>
              <div className="space-y-6">
                {[
                  {
                    icon: MapPin,
                    title: 'The Atelier',
                    content: '14 Rue des Fleurs\n75006 Paris, France',
                  },
                  {
                    icon: Mail,
                    title: 'Email',
                    content: 'bonjour@lumivere.paris\npress@lumivere.paris',
                  },
                  {
                    icon: Clock,
                    title: 'Response Time',
                    content: 'Monday – Friday\n9:00 – 18:00 CET\nWe reply within 24 hours',
                  },
                  {
                    icon: Gift,
                    title: 'Corporate Gifting',
                    content: 'Bespoke candles for weddings,\nevents, and corporate gifts.\nMinimum 10 pieces.',
                  },
                ].map(item => (
                  <div key={item.title} className="flex gap-4">
                    <div
                      className="w-10 h-10 flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: 'oklch(0.88 0.04 10 / 0.2)' }}
                    >
                      <item.icon size={16} className="text-gold" strokeWidth={1.5} />
                    </div>
                    <div>
                      <p className="text-label text-charcoal mb-1">{item.title}</p>
                      <p className="font-body font-light text-charcoal/65 text-sm whitespace-pre-line leading-relaxed">{item.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Gifting Banner */}
            <div
              id="gifting"
              className="p-8"
              style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}
            >
              <p className="text-label mb-3" style={{ color: 'oklch(0.75 0.10 82)' }}>Corporate Gifting</p>
              <h3 className="font-display text-2xl text-ivory mb-4" style={{ fontStyle: 'italic' }}>
                Give beauty. Be remembered.
              </h3>
              <p className="font-body font-light text-ivory/65 text-sm leading-relaxed mb-6">
                LUMIVÈRE candles make extraordinary corporate gifts. We offer bespoke packaging, custom fragrances, and handwritten notes for every order.
              </p>
              <button className="btn-luxury-outline" style={{ borderColor: 'oklch(0.975 0.008 85 / 0.3)', color: 'oklch(0.975 0.008 85)' }}>
                <span>Enquire About Gifting</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div id="faq" className="container py-16 border-t border-border">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12 reveal">
            <p className="text-label text-gold mb-4">Questions Fréquentes</p>
            <h2 className="font-display text-3xl text-charcoal" style={{ fontStyle: 'italic' }}>Frequently Asked</h2>
          </div>

          <div className="space-y-0 reveal reveal-delay-1">
            {faqs.map((faq, i) => (
              <div key={i} className="border-b border-border">
                <button
                  onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                  className="w-full flex items-start justify-between py-5 text-left gap-4"
                >
                  <span className="font-body text-sm font-medium text-charcoal leading-relaxed">{faq.q}</span>
                  <span
                    className="text-gold flex-shrink-0 transition-transform duration-300 mt-0.5"
                    style={{ transform: expandedFaq === i ? 'rotate(45deg)' : 'rotate(0deg)', fontSize: '18px' }}
                  >
                    +
                  </span>
                </button>
                {expandedFaq === i && (
                  <div className="pb-5">
                    <p className="font-body font-light text-charcoal/65 text-sm leading-relaxed">{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
