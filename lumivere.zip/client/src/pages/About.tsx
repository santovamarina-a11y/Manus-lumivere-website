/* LUMIVÈRE About Page — La Maison */

import { Link } from 'wouter';
import { useRevealOnMount } from '@/hooks/useScrollReveal';

const values = [
  {
    number: '01',
    title: 'The Flower',
    description: 'Every LUMIVÈRE candle begins with a single flower studied at its most perfect moment of bloom. Our artisans sketch each petal, each curve, each shadow before a single gram of wax is melted.',
  },
  {
    number: '02',
    title: 'The Wax',
    description: 'We use only 100% natural soy wax — sustainably sourced, clean-burning, and kind to the air you breathe. No paraffin. No compromise.',
  },
  {
    number: '03',
    title: 'The Scent',
    description: 'Our fragrances are composed by a Grasse-trained perfumer using rare botanical extracts. Each scent is designed to complement the flower it inhabits — never overpower it.',
  },
  {
    number: '04',
    title: 'The Hand',
    description: 'Each candle is sculpted by hand in our Paris atelier. No moulds. No machines. Just skilled hands, warm wax, and forty-eight hours of patient craft.',
  },
];

const team = [
  {
    name: 'Élise Moreau',
    role: 'Founder & Creative Director',
    bio: 'Former florist turned candle sculptor. Élise spent seven years arranging flowers for Parisian weddings before asking the question that started everything: what if the bouquet could last forever?',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-team-elise-3iJw9fKg3oXcF258uTYJ6K.webp',
  },
  {
    name: 'Jean-Baptiste Roux',
    role: 'Master Perfumer',
    bio: 'Trained in Grasse, the perfume capital of the world. Jean-Baptiste creates each LUMIVÈRE fragrance as a portrait of its flower — intimate, precise, unforgettable.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-team-jb-nsmXcxeZSpbSmE5rM8UgNS.webp',
  },
];

export default function About() {
  useRevealOnMount([]);

  return (
    <div className="min-h-screen bg-ivory pt-20">
      {/* Hero */}
      <div className="relative h-[70vh] min-h-[500px] flex items-end overflow-hidden">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-atelier-PvYdNxmoxk9cUa3cf78pNb.webp"
          alt="The Maison of LUMIVÈRE"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, oklch(0.22 0.01 60 / 0.9) 0%, oklch(0.22 0.01 60 / 0.4) 50%, transparent 100%)' }}
        />
        <div className="relative z-10 container pb-20">
          <p className="text-label mb-4" style={{ color: 'oklch(0.75 0.10 82)' }}>Notre Histoire</p>
          <h1 className="font-display text-5xl md:text-7xl text-ivory mb-4" style={{ fontStyle: 'italic', fontWeight: 300, lineHeight: 1.05 }}>
            The Maison
            <br />
            of LUMIVÈRE
          </h1>
          <p className="font-body font-light text-ivory/70 max-w-lg text-lg leading-relaxed">
            A love letter to flowers. A devotion to craft. A belief that beauty should be permanent.
          </p>
        </div>
      </div>

      {/* Opening Story */}
      <section className="py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <div className="reveal">
              <div className="flex items-center justify-center gap-4 mb-8">
                <div className="gold-rule-short" />
                <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '8px' }}>✦</span>
                <div className="gold-rule-short" />
              </div>
              <p className="font-display text-3xl md:text-4xl text-charcoal leading-relaxed" style={{ fontStyle: 'italic' }}>
                "What if the most beautiful moment of a flower — that single day when it is most perfectly itself — could be captured forever?"
              </p>
              <div className="flex items-center justify-center gap-4 mt-8">
                <div className="gold-rule-short" />
                <span className="font-body text-sm text-muted-foreground">Élise Moreau, Founder</span>
                <div className="gold-rule-short" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Sections */}
      <section className="py-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[60vh]">
          <div
            className="flex items-center px-8 py-20 lg:px-16 lg:py-24 order-2 lg:order-1"
            style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}
          >
            <div className="max-w-lg">
              <div className="reveal">
                <p className="text-label text-gold mb-6">2019 · Paris, France</p>
                <h2 className="text-section-title text-charcoal mb-8">
                  It began in a
                  <br />
                  <span style={{ fontStyle: 'italic', color: 'oklch(0.72 0.07 12)' }}>small atelier.</span>
                </h2>
              </div>
              <div className="space-y-5 reveal reveal-delay-1">
                <p className="font-body font-light text-charcoal/75 leading-relaxed">
                  LUMIVÈRE was born in a 40-square-metre atelier in the 6th arrondissement of Paris, where Élise Moreau — a florist who had spent seven years arranging flowers for Parisian weddings — had a simple, obsessive idea.
                </p>
                <p className="font-body font-light text-charcoal/75 leading-relaxed">
                  She wanted to make a candle that looked exactly like a real flower. Not a candle shaped vaguely like a flower. A candle that could be mistaken for one.
                </p>
                <p className="font-body font-light text-charcoal/75 leading-relaxed">
                  It took two years, forty-seven prototypes, and one chance meeting with a Grasse perfumer named Jean-Baptiste Roux before the first LUMIVÈRE candle was ready.
                </p>
              </div>
            </div>
          </div>
          <div className="relative overflow-hidden min-h-[50vh] order-1 lg:order-2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-bouquet-YNhXUaTMTXaPZbu33LEd4x.webp"
              alt="LUMIVÈRE atelier"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* The Craft — Values */}
      <section id="craft" className="py-24 bg-ivory">
        <div className="container">
          <div className="text-center mb-16 reveal">
            <p className="text-label text-gold mb-4">Le Savoir-Faire</p>
            <h2 className="text-section-title text-charcoal">The Four Principles</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {values.map((v, i) => (
              <div key={v.number} className={`reveal reveal-delay-${i + 1}`}>
                <div className="flex gap-8">
                  <span className="section-number flex-shrink-0" style={{ fontSize: '4rem' }}>{v.number}</span>
                  <div className="pt-2">
                    <h3 className="font-display text-2xl text-charcoal mb-4" style={{ fontStyle: 'italic' }}>{v.title}</h3>
                    <p className="font-body font-light text-charcoal/70 leading-relaxed">{v.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ingredients */}
      <section id="ingredients" className="py-24" style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}>
        <div className="container">
          <div className="text-center mb-16 reveal">
            <p className="text-label mb-4" style={{ color: 'oklch(0.75 0.10 82)' }}>Les Ingrédients</p>
            <h2 className="text-section-title text-ivory">Nothing Hidden. Nothing Harmful.</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: '100% Natural Soy Wax',
                description: 'Sustainably sourced from non-GMO soybeans. Burns cleanly, lasts longer, and carries fragrance more faithfully than paraffin.',
                icon: '🌿',
              },
              {
                title: 'Botanical Fragrances',
                description: 'Composed by a Grasse-trained perfumer using real botanical extracts — rose absolute, jasmine concrete, sandalwood oil. No synthetic shortcuts.',
                icon: '🌸',
              },
              {
                title: 'Cotton Wicks',
                description: 'Lead-free, unbleached cotton wicks that burn straight and true. No mushrooming. No black smoke. Just a clean, steady flame.',
                icon: '✦',
              },
            ].map((item, i) => (
              <div key={item.title} className={`text-center reveal reveal-delay-${i + 1}`}>
                <div className="text-4xl mb-6">{item.icon}</div>
                <h3 className="font-display text-xl text-ivory mb-4" style={{ fontStyle: 'italic' }}>{item.title}</h3>
                <p className="font-body font-light text-ivory/60 leading-relaxed text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 bg-ivory">
        <div className="container">
          <div className="text-center mb-16 reveal">
            <p className="text-label text-gold mb-4">L'Équipe</p>
            <h2 className="text-section-title text-charcoal">The Hands Behind the Flowers</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-3xl mx-auto">
            {team.map((member, i) => (
              <div key={member.name} className={`reveal reveal-delay-${i + 1}`}>
                <div className="aspect-[3/4] overflow-hidden mb-6 bg-warm-beige">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                  />
                </div>
                <p className="text-label text-gold mb-1">{member.role}</p>
                <h3 className="font-display text-2xl text-charcoal mb-3" style={{ fontStyle: 'italic' }}>{member.name}</h3>
                <p className="font-body font-light text-charcoal/70 leading-relaxed text-sm">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section
        className="py-24 text-center"
        style={{ backgroundColor: 'oklch(0.88 0.04 10 / 0.15)' }}
      >
        <div className="container reveal">
          <p className="text-label text-gold mb-6">La Collection LUMIVÈRE</p>
          <h2 className="text-section-title text-charcoal mb-8">
            Light one.
            <br />
            <span style={{ fontStyle: 'italic', color: 'oklch(0.72 0.07 12)' }}>The room remembers.</span>
          </h2>
          <Link href="/shop">
            <button className="btn-luxury">
              <span>Explore the Atelier</span>
            </button>
          </Link>
        </div>
      </section>
    </div>
  );
}
