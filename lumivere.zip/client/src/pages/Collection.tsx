/* LUMIVÈRE Collection Page — Editorial Atelier Layout */

import { useParams } from 'wouter';
import { ArrowRight } from 'lucide-react';
import { getProductsByCollection, collections, Product } from '@/lib/products';
import ProductCard from '@/components/ProductCard';
import { useRevealOnMount } from '@/hooks/useScrollReveal';
import { Link } from 'wouter';

const collectionHeroImages: Record<string, string> = {
  bouquet: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-bouquet-YNhXUaTMTXaPZbu33LEd4x.webp',
  zodiac: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
  seasonal: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-seasonal-NbE5FZrZFzdqPD2644veLD.webp',
};

const collectionNumerals: Record<string, string> = {
  bouquet: '01',
  zodiac: '02',
  seasonal: '03',
};

const collectionPoetry: Record<string, string> = {
  bouquet: 'Sculpted petal by petal. Each one a portrait of a flower at its most perfect moment.',
  zodiac: 'Embedded with semi-precious crystals and pressed botanicals. A ritual for every sign.',
  seasonal: 'Created in harmony with the seasons. When they are gone, they are gone forever.',
};

export default function Collection() {
  const params = useParams<{ id: string }>();
  const collectionId = params.id as Product['collection'];
  const collectionData = collections.find(c => c.id === collectionId);
  const collectionProducts = getProductsByCollection(collectionId);

  useRevealOnMount([collectionId]);

  if (!collectionData) {
    return (
      <div className="min-h-screen bg-ivory flex items-center justify-center pt-20">
        <div className="text-center">
          <p className="font-display text-3xl text-charcoal italic mb-4">This collection has not yet bloomed.</p>
          <Link href="/shop">
            <button className="btn-luxury-outline"><span>Explore the Boutique</span></button>
          </Link>
        </div>
      </div>
    );
  }

  const heroImage = collectionHeroImages[collectionId];
  const numeral = collectionNumerals[collectionId] || '01';
  const poetry = collectionPoetry[collectionId] || '';

  return (
    <div className="min-h-screen bg-ivory">
      {/* Hero — Full bleed with editorial text overlay */}
      <div className="relative h-[70vh] min-h-[500px] flex items-end overflow-hidden pt-20">
        <img
          src={heroImage}
          alt={collectionData.name}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, oklch(0.22 0.01 60 / 0.88) 0%, oklch(0.22 0.01 60 / 0.4) 50%, transparent 100%)' }}
        />

        {/* Oversized numeral */}
        <span
          className="absolute right-8 bottom-8 font-display select-none pointer-events-none hidden md:block"
          style={{
            fontSize: 'clamp(8rem, 18vw, 18rem)',
            fontWeight: 300,
            fontStyle: 'italic',
            color: 'oklch(0.975 0.008 85 / 0.05)',
            lineHeight: 1,
          }}
          aria-hidden
        >
          {numeral}
        </span>

        <div className="relative z-10 container pb-16">
          <div className="max-w-2xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="gold-rule-short" />
              <p className="text-label" style={{ color: 'oklch(0.75 0.10 82)' }}>{collectionData.subtitle}</p>
            </div>
            <h1 className="font-display text-5xl md:text-7xl text-ivory mb-5" style={{ fontStyle: 'italic', fontWeight: 300, lineHeight: 1.05 }}>
              {collectionData.name}
            </h1>
            <p className="font-body font-light text-ivory/65 max-w-lg leading-relaxed">{poetry}</p>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="container py-5 border-b border-border">
        <div className="flex items-center gap-2 text-label text-muted-foreground">
          <Link href="/" className="hover:text-gold transition-colors duration-300">Home</Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-gold transition-colors duration-300">Boutique</Link>
          <span>/</span>
          <span className="text-charcoal">{collectionData.name}</span>
        </div>
      </div>

      {/* Products — Editorial Layout */}
      <div className="container py-16">
        <div className="flex items-center justify-between mb-12 reveal">
          <p className="font-body text-sm text-muted-foreground">
            {collectionProducts.length} {collectionProducts.length === 1 ? 'piece' : 'pieces'} in this collection
          </p>
          <Link href="/shop" className="flex items-center gap-2 text-label text-muted-foreground hover:text-gold transition-colors duration-300 group">
            <span>All Collections</span>
            <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </div>

        {collectionProducts.length > 0 ? (
          <div>
            {/* First row: large feature + standard */}
            {collectionProducts.length >= 1 && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-6">
                {/* Large feature card */}
                <div className="md:col-span-5 reveal">
                  <Link href={`/product/${collectionProducts[0].id}`}>
                    <div className="group cursor-pointer">
                      <div className="overflow-hidden" style={{ aspectRatio: '3/4' }}>
                        <img
                          src={collectionProducts[0].image}
                          alt={collectionProducts[0].name}
                          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                        />
                      </div>
                      <div className="pt-4">
                        <p className="text-label text-muted-foreground mb-1">{collectionProducts[0].subtitle}</p>
                        <h3 className="font-display text-2xl text-charcoal group-hover:text-gold transition-colors duration-300" style={{ fontStyle: 'italic' }}>
                          {collectionProducts[0].name}
                        </h3>
                        <p className="font-body text-sm text-charcoal mt-1">€{collectionProducts[0].price}</p>
                      </div>
                    </div>
                  </Link>
                </div>

                {/* Standard cards */}
                <div className="md:col-span-7 grid grid-cols-2 gap-6 content-start">
                  {collectionProducts.slice(1, 3).map((product, i) => (
                    <ProductCard key={product.id} product={product} revealDelay={(i + 1) * 100} />
                  ))}

                  {/* Poetry insert between rows */}
                  {collectionProducts.length > 3 && (
                    <div
                      className="col-span-2 py-5 reveal reveal-delay-3"
                      style={{ borderTop: '1px solid oklch(0.88 0.015 75)', borderBottom: '1px solid oklch(0.88 0.015 75)' }}
                    >
                      <div className="flex items-center gap-6">
                        <div className="gold-rule-short flex-shrink-0" />
                        <p className="font-display text-base text-charcoal/40 italic">
                          {collectionData.description}
                        </p>
                        <div className="gold-rule-short flex-shrink-0 ml-auto" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Remaining products */}
            {collectionProducts.length > 3 && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 pt-6">
                {collectionProducts.slice(3).map((product, i) => (
                  <ProductCard key={product.id} product={product} revealDelay={i * 80} />
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-24">
            <p className="font-display text-3xl text-charcoal italic mb-4">Being crafted with care.</p>
            <p className="text-muted-foreground font-body font-light mb-8">This collection is being prepared. Return soon.</p>
            <Link href="/shop">
              <button className="btn-luxury-outline"><span>Explore the Boutique</span></button>
            </Link>
          </div>
        )}
      </div>

      {/* Collection Signature Block */}
      <div className="py-16" style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}>
        <div className="container">
          <div className="flex flex-col md:flex-row items-center gap-8 reveal">
            <div className="flex-shrink-0">
              <span
                className="font-display select-none"
                style={{
                  fontSize: '6rem',
                  fontWeight: 300,
                  fontStyle: 'italic',
                  color: 'oklch(0.22 0.01 60 / 0.08)',
                  lineHeight: 1,
                }}
              >
                {numeral}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-label text-gold mb-3">La Promesse LUMIVÈRE</p>
              <p className="font-display text-2xl md:text-3xl text-charcoal" style={{ fontStyle: 'italic', fontWeight: 300 }}>
                "Every piece leaves our atelier only when it is worthy of the name it carries."
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Other Collections */}
      <div className="container py-16 border-t border-border">
        <div className="flex items-end justify-between mb-12 reveal">
          <div>
            <p className="text-label text-gold mb-3">Discover More</p>
            <h2 className="font-display text-3xl text-charcoal" style={{ fontStyle: 'italic' }}>Other Collections</h2>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {collections.filter(c => c.id !== collectionId).slice(0, 2).map((col, i) => (
            <Link key={col.id} href={`/collections/${col.id}`}>
              <div className={`group relative overflow-hidden cursor-pointer reveal`} style={{ transitionDelay: `${i * 150}ms` }}>
                <div className="aspect-[16/9] overflow-hidden">
                  <img
                    src={collectionHeroImages[col.id]}
                    alt={col.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, oklch(0.22 0.01 60 / 0.75) 0%, transparent 60%)' }} />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <p className="text-label mb-1" style={{ color: 'oklch(0.75 0.10 82)' }}>{col.subtitle}</p>
                  <h3 className="font-display text-2xl text-ivory mb-2" style={{ fontStyle: 'italic' }}>{col.name}</h3>
                  <div className="flex items-center gap-2 text-ivory/60 group-hover:text-gold transition-colors duration-300">
                    <span className="text-label">Explore</span>
                    <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
