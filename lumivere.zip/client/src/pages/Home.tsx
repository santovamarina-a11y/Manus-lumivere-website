/* LUMIVÈRE Homepage — Parisian Atelier Romantique
   Sections: Hero · Collections · Best Sellers · Brand Story · Testimonials · Instagram · Newsletter */

import { useEffect, useRef, useState } from 'react';
import { Link } from 'wouter';
import { ArrowRight, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { useRevealOnMount } from '@/hooks/useScrollReveal';
import ProductCard from '@/components/ProductCard';
import { bestSellers, collections } from '@/lib/products';

// ── Floating Petals ──────────────────────────────────────────
function FloatingPetals() {
  const petals = Array.from({ length: 12 }, (_, i) => ({
    id: i,
    left: `${5 + (i * 8.5) % 90}%`,
    delay: `${i * 2.3}s`,
    duration: `${18 + (i * 3.7) % 20}s`,
    size: `${8 + (i * 1.5) % 10}px`,
    rotate: i % 2 === 0 ? 'petalFloat' : 'petalFloat2',
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden>
      {petals.map(petal => (
        <div
          key={petal.id}
          className="petal"
          style={{
            left: petal.left,
            top: '-5%',
            width: petal.size,
            height: `calc(${petal.size} * 1.3)`,
            animationName: petal.rotate,
            animationDuration: petal.duration,
            animationDelay: petal.delay,
            animationTimingFunction: 'linear',
            animationIterationCount: 'infinite',
          }}
        />
      ))}
    </div>
  );
}

// ── Testimonials Data ────────────────────────────────────────
const testimonials = [
  {
    id: 1,
    text: "I received the Pivoine Éternelle as a gift and I have never experienced anything like it. It is not a candle — it is a sculpture. The room smells like a Parisian garden.",
    author: "Amélie D.",
    location: "Paris",
    rating: 5,
  },
  {
    id: 2,
    text: "The packaging alone made me cry. Then I lit the Rose de Minuit and I understood what luxury truly means. LUMIVÈRE has ruined every other candle for me.",
    author: "Sofia M.",
    location: "Milan",
    rating: 5,
  },
  {
    id: 3,
    text: "I ordered the Zodiac set for my daughter's birthday. She said it was the most beautiful gift she had ever received. The crystals, the wax, the scent — everything is perfection.",
    author: "Catherine B.",
    location: "London",
    rating: 5,
  },
  {
    id: 4,
    text: "Three months later, I still cannot bring myself to light the Dahlia Noir. It sits on my mantelpiece like a piece of art. That says everything.",
    author: "Isabelle R.",
    location: "Brussels",
    rating: 5,
  },
];

// ── Instagram Gallery ────────────────────────────────────────
const instagramImages = [
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-rose-h5kGVBJnRx8n9jprE2AyMu.webp',
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-atelier-PvYdNxmoxk9cUa3cf78pNb.webp',
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-peony-YipPMMyqLkerp7Skc6EcHb.webp',
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-seasonal-NbE5FZrZFzdqPD2644veLD.webp',
  'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-dahlia-44df2EasezzUDJrMmei8Ma.webp',
];

// ── Main Component ───────────────────────────────────────────
export default function Home() {
  const [heroLoaded, setHeroLoaded] = useState(false);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useRevealOnMount([heroLoaded]);

  const nextTestimonial = () => setTestimonialIndex(i => (i + 1) % testimonials.length);
  const prevTestimonial = () => setTestimonialIndex(i => (i - 1 + testimonials.length) % testimonials.length);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  // Auto-advance testimonials
  useEffect(() => {
    const interval = setInterval(nextTestimonial, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main>
      {/* ══════════════════════════════════════════════════════
          HERO SECTION
          ══════════════════════════════════════════════════════ */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}
      >
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-hero-YwV6DrFbRMuAGZQPJRUt5m.webp"
            alt="LUMIVÈRE hero"
            className="w-full h-full object-cover"
            style={{
              opacity: heroLoaded ? 0.75 : 0,
              transition: 'opacity 1.5s cubic-bezier(0.23, 1, 0.32, 1)',
            }}
            onLoad={() => setHeroLoaded(true)}
          />
          {/* Gradient overlay */}
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(to right, oklch(0.22 0.01 60 / 0.7) 0%, oklch(0.22 0.01 60 / 0.3) 50%, oklch(0.22 0.01 60 / 0.1) 100%)',
            }}
          />
          <div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(to top, oklch(0.22 0.01 60 / 0.6) 0%, transparent 40%)',
            }}
          />
        </div>

        {/* Floating Petals */}
        <FloatingPetals />

        {/* Hero Content */}
        <div className="relative z-10 container">
          <div className="max-w-2xl">
            {/* Pre-headline */}
            <div
              className="flex items-center gap-4 mb-8"
              style={{
                opacity: heroLoaded ? 1 : 0,
                transform: heroLoaded ? 'translateY(0)' : 'translateY(20px)',
                transition: 'opacity 1s ease 0.3s, transform 1s ease 0.3s',
              }}
            >
              <div style={{ width: '2rem', height: '1px', backgroundColor: 'oklch(0.75 0.10 82)' }} />
              <span className="text-label" style={{ color: 'oklch(0.75 0.10 82)', letterSpacing: '0.25em' }}>
                Paris · Maison de Bougies Florales
              </span>
            </div>

            {/* Main Headline */}
            <h1
              className="text-hero text-ivory mb-6"
              style={{
                opacity: heroLoaded ? 1 : 0,
                transform: heroLoaded ? 'translateY(0)' : 'translateY(30px)',
                transition: 'opacity 1.2s ease 0.5s, transform 1.2s ease 0.5s',
              }}
            >
              More Than Candles.
              <br />
              <span style={{ color: 'oklch(0.88 0.04 10)' }}>Living Bouquets.</span>
            </h1>

            {/* Subheadline */}
            <p
              className="font-body font-light text-lg mb-10 max-w-lg"
              style={{
                color: 'oklch(0.975 0.008 85 / 0.75)',
                opacity: heroLoaded ? 1 : 0,
                transform: heroLoaded ? 'translateY(0)' : 'translateY(20px)',
                transition: 'opacity 1s ease 0.7s, transform 1s ease 0.7s',
                lineHeight: 1.8,
              }}
            >
              Handcrafted floral candles designed to illuminate extraordinary moments.
            </p>

            {/* CTAs */}
            <div
              className="flex flex-wrap gap-4"
              style={{
                opacity: heroLoaded ? 1 : 0,
                transform: heroLoaded ? 'translateY(0)' : 'translateY(20px)',
                transition: 'opacity 1s ease 0.9s, transform 1s ease 0.9s',
              }}
            >
              <Link href="/shop">
                <button className="btn-luxury">
                  <span>Discover the Collection</span>
                </button>
              </Link>
              <Link href="/about">
                <button
                  className="flex items-center gap-3 font-body text-xs tracking-[0.2em] uppercase transition-all duration-300 group"
                  style={{ color: 'oklch(0.975 0.008 85 / 0.7)' }}
                >
                  <span>Our Story</span>
                  <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
                </button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          style={{
            opacity: heroLoaded ? 0.6 : 0,
            transition: 'opacity 1s ease 1.5s',
          }}
        >
          <span className="text-label" style={{ color: 'oklch(0.975 0.008 85 / 0.5)' }}>Scroll</span>
          <div
            className="w-px h-12"
            style={{
              background: 'linear-gradient(to bottom, oklch(0.975 0.008 85 / 0.5), transparent)',
              animation: 'pulse 2s ease-in-out infinite',
            }}
          />
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════
          MARQUEE STRIP
          ══════════════════════════════════════════════════════ */}
      <div
        className="overflow-hidden py-4"
        style={{ backgroundColor: 'oklch(0.22 0.01 60)', borderTop: '1px solid oklch(0.75 0.10 82 / 0.2)' }}
      >
        <div className="marquee-track">
          {[...Array(2)].map((_, setIdx) => (
            <div key={setIdx} className="flex items-center">
              {['Handcrafted Soy Wax', 'Paris, France', 'Free Shipping Over €120', 'Gift Wrapping Included', 'Natural Botanicals', 'Limited Editions', 'Luxury Gifting'].map((text, i) => (
                <div key={i} className="flex items-center gap-6 px-6">
                  <span className="text-label" style={{ color: 'oklch(0.975 0.008 85 / 0.5)', whiteSpace: 'nowrap' }}>{text}</span>
                  <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '6px' }}>✦</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════
          FEATURED COLLECTIONS
          ══════════════════════════════════════════════════════ */}
      <section className="py-24 bg-ivory">
        <div className="container">
          {/* Section Header */}
          <div className="text-center mb-16 reveal">
            <p className="text-label text-gold mb-4">Les Collections</p>
            <h2 className="text-section-title text-charcoal">Three Worlds of Beauty</h2>
            <div className="flex items-center justify-center gap-4 mt-6">
              <div className="gold-rule-short" />
              <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '8px' }}>✦</span>
              <div className="gold-rule-short" />
            </div>
          </div>

          {/* Collections Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {collections.map((col, i) => (
              <Link key={col.id} href={`/collections/${col.id}`}>
                <div
                  className="group relative overflow-hidden cursor-pointer reveal"
                  style={{ transitionDelay: `${i * 120}ms` }}
                >
                  <div className="aspect-[3/4] overflow-hidden">
                    <img
                      src={col.image}
                      alt={col.name}
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    />
                    <div
                      className="absolute inset-0 transition-opacity duration-500"
                      style={{
                        background: 'linear-gradient(to top, oklch(0.22 0.01 60 / 0.75) 0%, oklch(0.22 0.01 60 / 0.2) 50%, transparent 100%)',
                      }}
                    />
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-8">
                    <p className="text-label mb-2" style={{ color: 'oklch(0.75 0.10 82)' }}>{col.subtitle}</p>
                    <h3 className="font-display text-2xl text-ivory mb-2" style={{ fontStyle: 'italic' }}>{col.name}</h3>
                    <p className="text-sm font-body font-light text-ivory/60 mb-4 leading-relaxed">{col.description}</p>
                    <div className="flex items-center gap-2 text-ivory/70 group-hover:text-gold transition-colors duration-300">
                      <span className="text-label">Explore</span>
                      <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════
          BEST SELLERS
          ══════════════════════════════════════════════════════ */}
      <section className="py-24" style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}>
        <div className="container">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
            <div className="reveal">
              <p className="text-label text-gold mb-4">Les Favoris</p>
              <h2 className="text-section-title text-charcoal">Best Sellers</h2>
            </div>
            <Link href="/shop?filter=bestsellers" className="mt-6 md:mt-0 reveal reveal-delay-2">
              <div className="flex items-center gap-2 text-charcoal hover:text-gold transition-colors duration-300 group">
                <span className="text-label">View All</span>
                <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </Link>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {bestSellers.map((product, i) => (
              <ProductCard key={product.id} product={product} revealDelay={i * 100} />
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════
          BRAND STORY
          ══════════════════════════════════════════════════════ */}
      <section className="py-0 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[80vh]">
          {/* Image Side */}
          <div className="relative overflow-hidden min-h-[50vh] lg:min-h-0">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-atelier-PvYdNxmoxk9cUa3cf78pNb.webp"
              alt="The Maison of LUMIVÈRE"
              className="w-full h-full object-cover"
            />
            <div
              className="absolute inset-0"
              style={{ background: 'linear-gradient(to right, transparent 60%, oklch(0.975 0.008 85) 100%)' }}
            />
          </div>

          {/* Text Side */}
          <div
            className="flex items-center px-8 py-20 lg:px-16 lg:py-24"
            style={{ backgroundColor: 'oklch(0.975 0.008 85)' }}
          >
            <div className="max-w-lg">
              <div className="reveal">
                <p className="text-label text-gold mb-6">La Maison LUMIVÈRE</p>
                <h2 className="text-section-title text-charcoal mb-2">
                  Born from a
                  <br />
                  <span style={{ fontStyle: 'italic', color: 'oklch(0.72 0.07 12)' }}>love of flowers.</span>
                </h2>
              </div>

              <div className="gold-rule my-8 reveal reveal-delay-1" />

              <div className="space-y-5 reveal reveal-delay-2">
                <p className="font-body font-light text-charcoal/75 leading-relaxed">
                  LUMIVÈRE was born in a small Parisian atelier, where a florist and a perfumer fell in love with the same question: <em>what if a bouquet could last forever?</em>
                </p>
                <p className="font-body font-light text-charcoal/75 leading-relaxed">
                  Each candle begins as a sketch — a flower studied in its most perfect moment of bloom. Then, petal by petal, it is sculpted by hand from the finest natural soy wax, scented with rare botanical extracts.
                </p>
                <p className="font-body font-light text-charcoal/75 leading-relaxed">
                  The result is not a candle. It is a conversation piece. A work of art that happens to fill your home with the most beautiful fragrance you have ever known.
                </p>
              </div>

              <div className="mt-10 reveal reveal-delay-3">
                <Link href="/about">
                  <button className="btn-luxury-outline">
                    <span>Discover Our Story</span>
                  </button>
                </Link>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 mt-12 pt-10 border-t border-border reveal reveal-delay-4">
                {[
                  { number: '100%', label: 'Natural Soy Wax' },
                  { number: '48h', label: 'Handcrafted Per Piece' },
                  { number: '12', label: 'Botanical Scents' },
                ].map(stat => (
                  <div key={stat.label} className="text-center">
                    <p className="font-display text-3xl text-gold" style={{ fontStyle: 'italic' }}>{stat.number}</p>
                    <p className="text-label text-muted-foreground mt-1">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════
          TESTIMONIALS
          ══════════════════════════════════════════════════════ */}
      <section className="py-24" style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}>
        <div className="container">
          {/* Section Header */}
          <div className="text-center mb-16 reveal">
            <p className="text-label mb-4" style={{ color: 'oklch(0.75 0.10 82)' }}>Les Témoignages</p>
            <h2 className="text-section-title text-ivory">What They Say</h2>
          </div>

          {/* Testimonial Carousel */}
          <div className="max-w-3xl mx-auto">
            <div className="relative min-h-[200px]">
              {testimonials.map((t, i) => (
                <div
                  key={t.id}
                  className="absolute inset-0 flex flex-col items-center text-center transition-all duration-700"
                  style={{
                    opacity: i === testimonialIndex ? 1 : 0,
                    transform: i === testimonialIndex ? 'translateY(0)' : 'translateY(16px)',
                    pointerEvents: i === testimonialIndex ? 'all' : 'none',
                  }}
                >
                  {/* Stars */}
                  <div className="flex gap-1 mb-6">
                    {Array.from({ length: t.rating }).map((_, si) => (
                      <Star key={si} size={14} className="fill-gold text-gold" />
                    ))}
                  </div>

                  {/* Quote */}
                  <blockquote className="font-display text-xl md:text-2xl text-ivory/90 leading-relaxed mb-8" style={{ fontStyle: 'italic' }}>
                    "{t.text}"
                  </blockquote>

                  {/* Author */}
                  <div className="flex items-center gap-3">
                    <div className="gold-rule-short" />
                    <div className="text-center">
                      <p className="font-body text-sm text-ivory/80">{t.author}</p>
                      <p className="text-label text-ivory/40 mt-0.5">{t.location}</p>
                    </div>
                    <div className="gold-rule-short" />
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-6 mt-12">
              <button
                onClick={prevTestimonial}
                className="w-10 h-10 flex items-center justify-center border transition-colors duration-300 hover:border-gold hover:text-gold"
                style={{ borderColor: 'oklch(0.975 0.008 85 / 0.2)', color: 'oklch(0.975 0.008 85 / 0.5)' }}
                aria-label="Previous testimonial"
              >
                <ChevronLeft size={16} />
              </button>
              <div className="flex gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setTestimonialIndex(i)}
                    className="transition-all duration-300"
                    style={{
                      width: i === testimonialIndex ? '2rem' : '0.5rem',
                      height: '1px',
                      backgroundColor: i === testimonialIndex ? 'oklch(0.75 0.10 82)' : 'oklch(0.975 0.008 85 / 0.3)',
                    }}
                    aria-label={`Testimonial ${i + 1}`}
                  />
                ))}
              </div>
              <button
                onClick={nextTestimonial}
                className="w-10 h-10 flex items-center justify-center border transition-colors duration-300 hover:border-gold hover:text-gold"
                style={{ borderColor: 'oklch(0.975 0.008 85 / 0.2)', color: 'oklch(0.975 0.008 85 / 0.5)' }}
                aria-label="Next testimonial"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════
          INSTAGRAM GALLERY
          ══════════════════════════════════════════════════════ */}
      <section className="py-24 bg-ivory">
        <div className="container">
          <div className="text-center mb-12 reveal">
            <p className="text-label text-gold mb-4">@lumivere.paris</p>
            <h2 className="text-section-title text-charcoal">Follow the Atelier</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
            {instagramImages.map((src, i) => (
              <a
                key={i}
                href="#"
                className="group relative overflow-hidden aspect-square reveal"
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <img
                  src={src}
                  alt={`LUMIVÈRE Instagram ${i + 1}`}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div
                  className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ backgroundColor: 'oklch(0.22 0.01 60 / 0.5)' }}
                >
                  <span className="text-ivory" style={{ fontSize: '20px' }}>✦</span>
                </div>
              </a>
            ))}
          </div>

          <div className="text-center mt-10 reveal">
            <a
              href="#"
              className="inline-flex items-center gap-2 text-charcoal hover:text-gold transition-colors duration-300 group"
            >
              <span className="text-label">Follow on Instagram</span>
              <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════
          NEWSLETTER
          ══════════════════════════════════════════════════════ */}
      <section
        className="py-24 relative overflow-hidden"
        style={{ backgroundColor: 'oklch(0.88 0.04 10 / 0.15)' }}
      >
        {/* Background texture */}
        <div className="absolute inset-0 opacity-30">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-bouquet-YNhXUaTMTXaPZbu33LEd4x.webp"
            alt=""
            className="w-full h-full object-cover"
            aria-hidden
          />
          <div className="absolute inset-0" style={{ backgroundColor: 'oklch(0.975 0.008 85 / 0.85)' }} />
        </div>

        <div className="container relative z-10">
          <div className="max-w-xl mx-auto text-center">
            <div className="reveal">
              <p className="text-label text-gold mb-4">La Lettre de l'Atelier</p>
              <h2 className="text-section-title text-charcoal mb-4">
                Letters from
                <br />
                <span style={{ fontStyle: 'italic', color: 'oklch(0.72 0.07 12)' }}>the Atelier</span>
              </h2>
              <p className="font-body font-light text-charcoal/65 leading-relaxed mb-10">
                Be the first to discover new collections, receive exclusive offers, and receive our seasonal candle care guide. No noise. Only beauty.
              </p>
            </div>

            {subscribed ? (
              <div className="reveal">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="gold-rule-short" />
                  <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '8px' }}>✦</span>
                  <div className="gold-rule-short" />
                </div>
                <p className="font-display text-2xl text-charcoal italic">Merci. Welcome to the Atelier.</p>
                <p className="text-sm text-muted-foreground font-body font-light mt-2">Your first letter will arrive soon.</p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="reveal reveal-delay-2">
                <div className="flex gap-0 max-w-md mx-auto">
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="Your email address"
                    className="input-luxury flex-1"
                    required
                  />
                  <button
                    type="submit"
                    className="px-6 py-3 font-body text-xs tracking-[0.2em] uppercase text-ivory transition-colors duration-300 flex-shrink-0"
                    style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}
                  >
                    Subscribe
                  </button>
                </div>
                <p className="text-xs text-muted-foreground font-body font-light mt-4">
                  By subscribing, you agree to our Privacy Policy. Unsubscribe at any time.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
