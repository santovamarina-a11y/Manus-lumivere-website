/* LUMIVÈRE 404 Page */

import { Link } from 'wouter';

export default function NotFound() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center text-center px-6"
      style={{ backgroundColor: 'oklch(0.975 0.008 85)' }}
    >
      {/* Decorative number */}
      <p
        className="font-display select-none pointer-events-none mb-0"
        style={{
          fontSize: 'clamp(8rem, 20vw, 18rem)',
          fontWeight: 300,
          fontStyle: 'italic',
          color: 'oklch(0.22 0.01 60 / 0.04)',
          lineHeight: 1,
        }}
      >
        404
      </p>

      <div className="-mt-8 md:-mt-16 relative z-10">
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="gold-rule-short" />
          <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '8px' }}>✦</span>
          <div className="gold-rule-short" />
        </div>

        <p className="text-label text-gold mb-4">Page Introuvable</p>
        <h1 className="font-display text-4xl md:text-6xl text-charcoal mb-4" style={{ fontStyle: 'italic', fontWeight: 300 }}>
          This page has bloomed
          <br />
          and faded.
        </h1>
        <p className="font-body font-light text-muted-foreground mb-10 max-w-md mx-auto leading-relaxed">
          The page you are looking for no longer exists — or perhaps it never did. Let us guide you back to the atelier.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <Link href="/">
            <button className="btn-luxury">
              <span>Return Home</span>
            </button>
          </Link>
          <Link href="/shop">
            <button className="btn-luxury-outline">
              <span>Explore the Collection</span>
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
