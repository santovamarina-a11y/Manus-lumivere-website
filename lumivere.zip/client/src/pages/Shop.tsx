/* LUMIVÈRE Shop Page — Editorial Atelier Layout
   Asymmetric grid, strong brand motifs, poetic language throughout */

import { useState, useEffect } from 'react';
import { useSearch, Link } from 'wouter';
import { SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import { products, Product } from '@/lib/products';
import ProductCard from '@/components/ProductCard';
import { useRevealOnMount } from '@/hooks/useScrollReveal';

type FilterType = 'all' | 'bouquet' | 'zodiac' | 'seasonal' | 'bestsellers' | 'new' | 'limited';
type SortType = 'featured' | 'price-asc' | 'price-desc' | 'newest';

export default function Shop() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const initialFilter = (params.get('filter') || 'all') as FilterType;

  const [activeFilter, setActiveFilter] = useState<FilterType>(initialFilter);
  const [activeSort, setActiveSort] = useState<SortType>('featured');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 250]);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);

  useRevealOnMount([activeFilter, activeSort]);

  const filters: { id: FilterType; label: string }[] = [
    { id: 'all', label: 'All Pieces' },
    { id: 'bouquet', label: 'Bouquet Candles' },
    { id: 'zodiac', label: 'Zodiac Crystal' },
    { id: 'seasonal', label: 'Seasonal Editions' },
    { id: 'bestsellers', label: 'Les Favoris' },
    { id: 'new', label: 'New Arrivals' },
    { id: 'limited', label: 'Éditions Limitées' },
  ];

  const sortOptions: { id: SortType; label: string }[] = [
    { id: 'featured', label: 'Curated Selection' },
    { id: 'price-asc', label: 'Price Ascending' },
    { id: 'price-desc', label: 'Price Descending' },
    { id: 'newest', label: 'Recent Arrivals' },
  ];

  const filteredProducts = products
    .filter(p => {
      if (activeFilter === 'all') return true;
      if (activeFilter === 'bestsellers') return p.isBestSeller;
      if (activeFilter === 'new') return p.isNew;
      if (activeFilter === 'limited') return p.isLimited;
      return p.collection === activeFilter;
    })
    .filter(p => p.price >= priceRange[0] && p.price <= priceRange[1])
    .sort((a, b) => {
      if (activeSort === 'price-asc') return a.price - b.price;
      if (activeSort === 'price-desc') return b.price - a.price;
      if (activeSort === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
      return 0;
    });

  useEffect(() => {
    setActiveFilter(initialFilter);
  }, [initialFilter]);

  return (
    <div className="min-h-screen bg-ivory pt-20">
      {/* Page Header — Editorial */}
      <div className="relative overflow-hidden py-24" style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}>
        {/* Oversized background numeral */}
        <span
          className="absolute right-8 top-1/2 -translate-y-1/2 font-display select-none pointer-events-none"
          style={{
            fontSize: 'clamp(10rem, 22vw, 22rem)',
            fontWeight: 300,
            fontStyle: 'italic',
            color: 'oklch(0.22 0.01 60 / 0.04)',
            lineHeight: 1,
          }}
          aria-hidden
        >
          01
        </span>

        <div className="container relative z-10">
          <div className="max-w-xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="gold-rule-short" />
              <p className="text-label text-gold">La Boutique</p>
            </div>
            <h1 className="text-section-title text-charcoal mb-4">
              The Collection
            </h1>
            <p className="font-body font-light text-muted-foreground leading-relaxed">
              {filteredProducts.length} {filteredProducts.length === 1 ? 'piece' : 'pieces'} — each one sculpted by hand, scented with intention.
            </p>
          </div>
        </div>
      </div>

      <div className="container py-12">
        {/* Filter Bar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-12">
          {/* Category Filters */}
          <div className="flex flex-wrap gap-2">
            {filters.map(f => (
              <button
                key={f.id}
                onClick={() => setActiveFilter(f.id)}
                className="text-label px-4 py-2 border transition-all duration-300"
                style={{
                  borderColor: activeFilter === f.id ? 'oklch(0.75 0.10 82)' : 'oklch(0.88 0.015 75)',
                  backgroundColor: activeFilter === f.id ? 'oklch(0.22 0.01 60)' : 'transparent',
                  color: activeFilter === f.id ? 'oklch(0.975 0.008 85)' : 'oklch(0.55 0.02 60)',
                }}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Sort + Filter Controls */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <button
                onClick={() => { setSortOpen(!sortOpen); setFiltersOpen(false); }}
                className="flex items-center gap-2 text-label text-muted-foreground hover:text-charcoal transition-colors duration-300 border border-border px-4 py-2"
              >
                <span>{sortOptions.find(s => s.id === activeSort)?.label}</span>
                <ChevronDown size={12} className={`transition-transform duration-300 ${sortOpen ? 'rotate-180' : ''}`} />
              </button>
              {sortOpen && (
                <div
                  className="absolute right-0 top-full mt-1 w-52 z-20 border border-border shadow-lg"
                  style={{ backgroundColor: 'oklch(0.975 0.008 85)' }}
                >
                  {sortOptions.map(opt => (
                    <button
                      key={opt.id}
                      onClick={() => { setActiveSort(opt.id); setSortOpen(false); }}
                      className="w-full text-left px-4 py-3 text-label transition-colors duration-200 hover:bg-warm-beige"
                      style={{ color: activeSort === opt.id ? 'oklch(0.75 0.10 82)' : 'oklch(0.55 0.02 60)' }}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => { setFiltersOpen(!filtersOpen); setSortOpen(false); }}
              className="flex items-center gap-2 text-label text-muted-foreground hover:text-charcoal transition-colors duration-300 border border-border px-4 py-2"
            >
              <SlidersHorizontal size={12} />
              <span>Refine</span>
            </button>
          </div>
        </div>

        {/* Price Filter Panel */}
        {filtersOpen && (
          <div className="mb-8 p-6 border border-border" style={{ backgroundColor: 'oklch(0.96 0.010 80)' }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-body text-sm font-medium text-charcoal tracking-wide">Price Range</h3>
              <button onClick={() => setFiltersOpen(false)} className="text-muted-foreground hover:text-charcoal">
                <X size={14} />
              </button>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-3">
                <span className="text-label text-muted-foreground">€{priceRange[0]}</span>
                <input type="range" min={0} max={250} value={priceRange[0]} onChange={e => setPriceRange([Number(e.target.value), priceRange[1]])} className="w-32 accent-gold" />
              </div>
              <span className="text-muted-foreground">—</span>
              <div className="flex items-center gap-3">
                <input type="range" min={0} max={250} value={priceRange[1]} onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])} className="w-32 accent-gold" />
                <span className="text-label text-muted-foreground">€{priceRange[1]}</span>
              </div>
              <button onClick={() => setPriceRange([0, 250])} className="text-label text-gold hover:text-dusty-rose transition-colors duration-300">Reset</button>
            </div>
          </div>
        )}

        {/* Products — Editorial Asymmetric Grid */}
        {filteredProducts.length > 0 ? (
          <div className="space-y-0">
            {/* Row 1: Large feature + 2 standard */}
            {filteredProducts.length >= 1 && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-6">
                {/* Featured large card */}
                <div className="md:col-span-5 reveal">
                  <Link href={`/product/${filteredProducts[0].id}`}>
                    <div className="group cursor-pointer">
                      <div
                        className="overflow-hidden"
                        style={{ aspectRatio: '3/4' }}
                      >
                        <img
                          src={filteredProducts[0].image}
                          alt={filteredProducts[0].name}
                          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                        />
                      </div>
                      <div className="pt-4">
                        <p className="text-label text-muted-foreground mb-1">{filteredProducts[0].subtitle}</p>
                        <h3 className="font-display text-2xl text-charcoal group-hover:text-gold transition-colors duration-300" style={{ fontStyle: 'italic' }}>{filteredProducts[0].name}</h3>
                        <p className="font-body text-sm text-charcoal mt-1">€{filteredProducts[0].price}</p>
                      </div>
                    </div>
                  </Link>
                </div>

                {/* 2 standard cards stacked */}
                <div className="md:col-span-7 grid grid-cols-2 gap-6 content-start">
                  {filteredProducts.slice(1, 3).map((product, i) => (
                    <ProductCard key={product.id} product={product} revealDelay={(i + 1) * 100} />
                  ))}
                  {/* Brand motif insert */}
                  {filteredProducts.length >= 4 && (
                    <div
                      className="col-span-2 flex items-center gap-6 py-6 reveal reveal-delay-3"
                      style={{ borderTop: '1px solid oklch(0.88 0.015 75)', borderBottom: '1px solid oklch(0.88 0.015 75)' }}
                    >
                      <div className="gold-rule-short flex-shrink-0" />
                      <p className="font-display text-lg text-charcoal/50 italic">
                        Sculpted by hand. Scented with intention.
                      </p>
                      <div className="gold-rule-short flex-shrink-0 ml-auto" />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Remaining products in standard 4-col grid */}
            {filteredProducts.length > 3 && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 pt-6">
                {filteredProducts.slice(3).map((product, i) => (
                  <ProductCard key={product.id} product={product} revealDelay={i * 60} />
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-24">
            <p className="font-display text-3xl text-charcoal italic mb-4">No pieces found</p>
            <p className="text-muted-foreground font-body font-light mb-8">Refine your selection to discover the collection.</p>
            <button onClick={() => { setActiveFilter('all'); setPriceRange([0, 250]); }} className="btn-luxury-outline">
              <span>Explore All Pieces</span>
            </button>
          </div>
        )}
      </div>

      {/* Editorial Brand Strip */}
      <div className="mt-16 py-16" style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}>
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[
              { number: '48h', label: 'Handcrafted per piece', sub: 'No moulds. No machines.' },
              { number: '100%', label: 'Natural soy wax', sub: 'Clean-burning, sustainable.' },
              { number: '€60–€200', label: 'Priced as art', sub: 'Because that is what they are.' },
            ].map((stat, i) => (
              <div key={stat.number} className={`reveal reveal-delay-${i + 1}`}>
                <p className="font-display text-4xl text-gold mb-2" style={{ fontStyle: 'italic' }}>{stat.number}</p>
                <p className="text-label text-ivory mb-1">{stat.label}</p>
                <p className="font-body font-light text-ivory/40 text-xs">{stat.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
