/* LUMIVÈRE Product Detail Page — Editorial Atelier Layout */

import { useState } from 'react';
import { useParams, Link } from 'wouter';
import { ChevronDown, ChevronUp, Heart, Share2, ArrowLeft, Star } from 'lucide-react';
import { getProductById, products } from '@/lib/products';
import { useCart } from '@/contexts/CartContext';
import ProductCard from '@/components/ProductCard';
import { useRevealOnMount } from '@/hooks/useScrollReveal';

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const product = getProductById(params.id);
  const { addItem } = useCart();

  const [selectedScent, setSelectedScent] = useState(0);
  const [selectedSize, setSelectedSize] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>('details');

  useRevealOnMount([params.id]);

  if (!product) {
    return (
      <div className="min-h-screen bg-ivory flex items-center justify-center pt-20">
        <div className="text-center">
          <p className="font-display text-3xl text-charcoal italic mb-4">This piece has found its home.</p>
          <Link href="/shop">
            <button className="btn-luxury-outline"><span>Explore the Collection</span></button>
          </Link>
        </div>
      </div>
    );
  }

  const relatedProducts = products
    .filter(p => p.collection === product.collection && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      scent: product.scents[selectedScent],
      size: product.sizes[selectedSize],
    });
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2500);
  };

  const accordionSections = [
    {
      id: 'details',
      title: 'The Piece',
      content: (
        <ul className="space-y-2">
          {product.details.map((d, i) => (
            <li key={i} className="flex items-center gap-3 text-sm font-body font-light text-charcoal/70">
              <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '6px' }}>✦</span>
              {d}
            </li>
          ))}
        </ul>
      ),
    },
    {
      id: 'care',
      title: 'Candle Ritual',
      content: (
        <div className="space-y-3 text-sm font-body font-light text-charcoal/70">
          <p>Trim the wick to 5mm before each lighting to ensure a clean, even burn.</p>
          <p>Allow the wax to melt to the edges on the first burn to prevent tunnelling.</p>
          <p>Never burn for more than 4 hours at a time. Keep away from draughts.</p>
          <p>Place on a heat-resistant surface. Never leave unattended.</p>
        </div>
      ),
    },
    {
      id: 'shipping',
      title: 'Delivery & Returns',
      content: (
        <div className="space-y-3 text-sm font-body font-light text-charcoal/70">
          <p>Complimentary standard shipping on orders over €120.</p>
          <p>Express delivery available (2–3 business days).</p>
          <p>Each order is gift-wrapped in our signature ivory box with a handwritten note.</p>
          <p>Returns accepted within 14 days for unopened, unused items.</p>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-ivory pt-20">
      {/* Breadcrumb */}
      <div className="container py-6 border-b border-border">
        <div className="flex items-center gap-2 text-label text-muted-foreground">
          <Link href="/" className="hover:text-gold transition-colors duration-300">Home</Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-gold transition-colors duration-300">Boutique</Link>
          <span>/</span>
          <Link href={`/collections/${product.collection}`} className="hover:text-gold transition-colors duration-300 capitalize">
            {product.collection === 'bouquet' ? 'Bouquet Candles' : product.collection === 'zodiac' ? 'Zodiac Crystal' : 'Seasonal Editions'}
          </Link>
          <span>/</span>
          <span className="text-charcoal">{product.name}</span>
        </div>
      </div>

      {/* Product Layout */}
      <div className="container py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          {/* Image — Left */}
          <div className="reveal">
            {/* Oversized collection label behind image */}
            <div className="relative">
              <span
                className="absolute -left-4 top-1/2 -translate-y-1/2 font-display select-none pointer-events-none hidden lg:block"
                style={{
                  fontSize: '12rem',
                  fontWeight: 300,
                  fontStyle: 'italic',
                  color: 'oklch(0.22 0.01 60 / 0.03)',
                  lineHeight: 1,
                  writingMode: 'vertical-rl',
                  textOrientation: 'mixed',
                  transform: 'translateY(-50%) rotate(180deg)',
                }}
                aria-hidden
              >
                {product.collection}
              </span>
              <div className="aspect-[3/4] overflow-hidden bg-warm-beige relative z-10">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Badges */}
            <div className="flex gap-2 mt-4">
              {product.isBestSeller && (
                <span className="text-label bg-charcoal text-ivory px-3 py-1.5">Les Favoris</span>
              )}
              {product.isNew && (
                <span className="text-label bg-gold text-charcoal px-3 py-1.5">Nouvelle Arrivée</span>
              )}
              {product.isLimited && (
                <span className="text-label border border-burgundy text-burgundy px-3 py-1.5">Édition Limitée</span>
              )}
            </div>
          </div>

          {/* Product Info — Right */}
          <div className="reveal reveal-delay-2">
            {/* Back Link */}
            <Link href={`/collections/${product.collection}`} className="inline-flex items-center gap-2 text-label text-muted-foreground hover:text-gold transition-colors duration-300 mb-8 group">
              <ArrowLeft size={12} className="transition-transform duration-300 group-hover:-translate-x-1" />
              <span>Return to {product.collection === 'bouquet' ? 'Bouquet Collection' : product.collection === 'zodiac' ? 'Zodiac Collection' : 'Seasonal Editions'}</span>
            </Link>

            {/* Title */}
            <p className="text-label text-gold mb-2">{product.subtitle}</p>
            <h1 className="font-display text-5xl md:text-6xl text-charcoal mb-3" style={{ fontStyle: 'italic', fontWeight: 300, lineHeight: 1.05 }}>
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-6">
              <div className="flex gap-0.5">
                {[1,2,3,4,5].map(s => (
                  <Star key={s} size={12} className="fill-gold text-gold" />
                ))}
              </div>
              <span className="text-label text-muted-foreground">4.9 · 127 reviews</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-8">
              <span className="font-display text-4xl text-charcoal">€{product.price}</span>
              {product.originalPrice && (
                <span className="font-body text-lg text-muted-foreground line-through">€{product.originalPrice}</span>
              )}
            </div>

            <div className="gold-rule mb-8" />

            {/* Description */}
            <p className="font-body font-light text-charcoal/75 leading-relaxed mb-8 text-base">
              {product.description}
            </p>

            {/* Scent Selection */}
            <div className="mb-6">
              <p className="text-label text-charcoal mb-3">
                Fragrance — <span className="text-gold">{product.scents[selectedScent]}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.scents.map((scent, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedScent(i)}
                    className="px-4 py-2 text-sm font-body font-light border transition-all duration-300"
                    style={{
                      borderColor: selectedScent === i ? 'oklch(0.75 0.10 82)' : 'oklch(0.88 0.015 75)',
                      backgroundColor: selectedScent === i ? 'oklch(0.975 0.008 85)' : 'transparent',
                      color: selectedScent === i ? 'oklch(0.22 0.01 60)' : 'oklch(0.55 0.02 60)',
                    }}
                  >
                    {scent}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div className="mb-8">
              <p className="text-label text-charcoal mb-3">
                Format — <span className="text-gold">{product.sizes[selectedSize]}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedSize(i)}
                    className="px-4 py-2 text-sm font-body font-light border transition-all duration-300"
                    style={{
                      borderColor: selectedSize === i ? 'oklch(0.75 0.10 82)' : 'oklch(0.88 0.015 75)',
                      backgroundColor: selectedSize === i ? 'oklch(0.975 0.008 85)' : 'transparent',
                      color: selectedSize === i ? 'oklch(0.22 0.01 60)' : 'oklch(0.55 0.02 60)',
                    }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity + Add to Atelier */}
            <div className="flex gap-4 mb-6">
              <div className="flex items-center border border-border">
                <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-10 h-12 flex items-center justify-center text-charcoal hover:text-gold transition-colors duration-200">−</button>
                <span className="w-10 text-center font-body text-sm">{quantity}</span>
                <button onClick={() => setQuantity(q => q + 1)} className="w-10 h-12 flex items-center justify-center text-charcoal hover:text-gold transition-colors duration-200">+</button>
              </div>

              <button
                onClick={handleAddToCart}
                className="btn-luxury flex-1"
                style={{
                  backgroundColor: addedToCart ? 'oklch(0.75 0.10 82)' : undefined,
                  borderColor: addedToCart ? 'oklch(0.75 0.10 82)' : undefined,
                }}
              >
                <span>{addedToCart ? '✓ Reserved in Your Atelier' : 'Add to Atelier'}</span>
              </button>

              <button
                onClick={() => setIsWishlisted(!isWishlisted)}
                className="w-12 h-12 flex items-center justify-center border border-border hover:border-gold transition-colors duration-300"
                aria-label="Add to wishlist"
              >
                <Heart size={16} strokeWidth={1.5} className={isWishlisted ? 'fill-burgundy text-burgundy' : 'text-charcoal'} />
              </button>
            </div>

            {/* Share */}
            <button className="flex items-center gap-2 text-label text-muted-foreground hover:text-gold transition-colors duration-300 mb-10">
              <Share2 size={12} />
              <span>Share this piece</span>
            </button>

            {/* Accordion Details */}
            <div className="border-t border-border">
              {accordionSections.map(section => (
                <div key={section.id} className="border-b border-border">
                  <button
                    onClick={() => setExpandedSection(expandedSection === section.id ? null : section.id)}
                    className="w-full flex items-center justify-between py-4 text-left"
                  >
                    <span className="font-body text-sm font-medium text-charcoal tracking-wide">{section.title}</span>
                    {expandedSection === section.id
                      ? <ChevronUp size={14} className="text-muted-foreground" />
                      : <ChevronDown size={14} className="text-muted-foreground" />
                    }
                  </button>
                  {expandedSection === section.id && (
                    <div className="pb-6">{section.content}</div>
                  )}
                </div>
              ))}
            </div>

            {/* Gifting note */}
            <div
              className="mt-8 p-6 flex items-start gap-4"
              style={{ backgroundColor: 'oklch(0.88 0.04 10 / 0.12)' }}
            >
              <span style={{ color: 'oklch(0.75 0.10 82)', fontSize: '10px', marginTop: '2px' }}>✦</span>
              <div>
                <p className="text-label text-charcoal mb-1">Complimentary Gift Wrapping</p>
                <p className="font-body font-light text-charcoal/65 text-sm leading-relaxed">
                  Every LUMIVÈRE order arrives in our signature ivory gift box with a handwritten note. No additional cost. Always.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="container py-16 border-t border-border">
          <div className="flex items-end justify-between mb-12 reveal">
            <div>
              <p className="text-label text-gold mb-3">You May Also Love</p>
              <h2 className="font-display text-3xl text-charcoal" style={{ fontStyle: 'italic' }}>Complete the Collection</h2>
            </div>
            <Link href={`/collections/${product.collection}`} className="text-label text-muted-foreground hover:text-gold transition-colors duration-300">
              View All
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} revealDelay={i * 100} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
