/* LUMIVÈRE Product Card — Editorial 3:4 portrait format */

import { useState } from 'react';
import { Link } from 'wouter';
import { ShoppingBag, Heart } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import type { Product } from '@/lib/products';

interface ProductCardProps {
  product: Product;
  className?: string;
  revealDelay?: number;
}

export default function ProductCard({ product, className = '', revealDelay = 0 }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      scent: product.scents[0],
      size: product.sizes[0],
    });
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlisted(!isWishlisted);
  };

  return (
    <Link href={`/product/${product.id}`}>
      <div
        className={`product-card group cursor-pointer reveal ${className}`}
        style={{ transitionDelay: `${revealDelay}ms` }}
      >
        {/* Image Container */}
        <div className="product-card-image relative">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.isBestSeller && (
              <span className="text-label bg-charcoal text-ivory px-2 py-1">Best Seller</span>
            )}
            {product.isNew && (
              <span className="text-label bg-gold text-charcoal px-2 py-1">New</span>
            )}
            {product.isLimited && (
              <span className="text-label border border-burgundy text-burgundy px-2 py-1">Limited</span>
            )}
          </div>

          {/* Wishlist */}
          <button
            onClick={handleWishlist}
            className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-ivory/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-ivory"
            aria-label="Add to wishlist"
          >
            <Heart
              size={14}
              strokeWidth={1.5}
              className={isWishlisted ? 'fill-burgundy text-burgundy' : 'text-charcoal'}
            />
          </button>

          {/* Quick Add Overlay */}
          <div className="absolute bottom-0 left-0 right-0 translate-y-full group-hover:translate-y-0 transition-transform duration-400 ease-out">
            <button
              onClick={handleAddToCart}
              className="w-full py-3 flex items-center justify-center gap-2 font-body text-xs tracking-[0.15em] uppercase transition-colors duration-300"
              style={{
                backgroundColor: addedToCart ? 'oklch(0.75 0.10 82)' : 'oklch(0.22 0.01 60)',
                color: addedToCart ? 'oklch(0.22 0.01 60)' : 'oklch(0.975 0.008 85)',
              }}
            >
              <ShoppingBag size={12} strokeWidth={1.5} />
              <span>{addedToCart ? 'Added to Atelier' : 'Quick Add'}</span>
            </button>
          </div>
        </div>

        {/* Product Info */}
        <div className="pt-4 pb-2">
          <p className="text-label text-muted-foreground mb-1">{product.subtitle}</p>
          <h3 className="font-display text-xl text-charcoal group-hover:text-gold transition-colors duration-300" style={{ fontStyle: 'italic' }}>
            {product.name}
          </h3>
          <div className="flex items-center justify-between mt-2">
            <span className="font-body text-sm text-charcoal">
              €{product.price}
              {product.originalPrice && (
                <span className="ml-2 text-muted-foreground line-through text-xs">€{product.originalPrice}</span>
              )}
            </span>
            <div className="flex gap-1">
              {product.scents.slice(0, 3).map((_, i) => (
                <div
                  key={i}
                  className="w-2 h-2 rounded-full border border-border"
                  style={{
                    backgroundColor: i === 0 ? 'oklch(0.88 0.04 10)' : i === 1 ? 'oklch(0.92 0.018 75)' : 'oklch(0.975 0.008 85)',
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
