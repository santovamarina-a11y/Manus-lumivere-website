/* LUMIVÈRE Cart Drawer — Parisian Atelier Romantique */

import { X, Minus, Plus, ShoppingBag } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { Link } from 'wouter';

export default function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, totalPrice, totalItems } = useCart();

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 transition-opacity duration-500"
        style={{
          backgroundColor: 'oklch(0.22 0.01 60 / 0.4)',
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? 'all' : 'none',
        }}
        onClick={closeCart}
      />

      {/* Drawer */}
      <div
        className="fixed top-0 right-0 bottom-0 z-50 w-full max-w-md flex flex-col"
        style={{
          backgroundColor: 'oklch(0.975 0.008 85)',
          transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.5s cubic-bezier(0.23, 1, 0.32, 1)',
          borderLeft: '1px solid oklch(0.88 0.015 75)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-8 py-6 border-b border-border">
          <div>
            <h2 className="font-display text-2xl text-charcoal">Your Atelier</h2>
            <p className="text-label text-muted-foreground mt-0.5">{totalItems} {totalItems === 1 ? 'piece' : 'pieces'}</p>
          </div>
          <button
            onClick={closeCart}
            className="text-charcoal hover:text-gold transition-colors duration-300"
            aria-label="Close cart"
          >
            <X size={20} strokeWidth={1.5} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-8 py-6">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-6 text-center">
              <ShoppingBag size={40} strokeWidth={1} className="text-muted-foreground" />
              <div>
                <p className="font-display text-2xl text-charcoal italic">Your atelier awaits</p>
                <p className="text-sm text-muted-foreground mt-2 font-body font-light">Discover our collections and add your first piece.</p>
              </div>
              <button onClick={closeCart} className="btn-luxury-outline">
                <span>Explore Collections</span>
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {items.map(item => (
                <div key={item.id} className="flex gap-4 cart-item-enter">
                  <div className="w-20 h-24 flex-shrink-0 overflow-hidden bg-warm-beige">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-display text-lg text-charcoal leading-tight">{item.name}</h3>
                        {item.scent && <p className="text-xs text-muted-foreground font-body font-light mt-0.5">{item.scent}</p>}
                        {item.size && <p className="text-xs text-muted-foreground font-body font-light">{item.size}</p>}
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-muted-foreground hover:text-burgundy transition-colors duration-200 flex-shrink-0"
                        aria-label="Remove item"
                      >
                        <X size={14} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-6 h-6 flex items-center justify-center border border-border hover:border-gold transition-colors duration-200"
                          aria-label="Decrease quantity"
                        >
                          <Minus size={10} />
                        </button>
                        <span className="text-sm font-body w-4 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-6 h-6 flex items-center justify-center border border-border hover:border-gold transition-colors duration-200"
                          aria-label="Increase quantity"
                        >
                          <Plus size={10} />
                        </button>
                      </div>
                      <span className="font-display text-lg text-charcoal">€{(item.price * item.quantity).toFixed(0)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="px-8 py-6 border-t border-border space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-label text-muted-foreground">Subtotal</span>
              <span className="font-display text-2xl text-charcoal">€{totalPrice.toFixed(0)}</span>
            </div>
            <p className="text-xs text-muted-foreground font-body font-light">Shipping and taxes calculated at checkout. Complimentary gift wrapping on all orders.</p>
            <button className="btn-luxury w-full">
              <span>Proceed to Checkout</span>
            </button>
            <Link href="/shop" onClick={closeCart} className="block text-center text-label text-muted-foreground hover:text-gold transition-colors duration-300">
              Continue Shopping
            </Link>
          </div>
        )}
      </div>
    </>
  );
}
