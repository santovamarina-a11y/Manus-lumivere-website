/* LUMIVÈRE Footer — Deep Charcoal with Champagne Gold accents */

import { Link } from 'wouter';
import { Instagram, Facebook, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer style={{ backgroundColor: 'oklch(0.22 0.01 60)' }}>
      {/* Top Section */}
      <div className="container py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-logo-7q7jKznznRE6eJXKwGLwKA.webp"
                alt="LUMIVÈRE"
                className="w-10 h-10 object-contain brightness-0 invert"
              />
              <span className="font-display text-2xl tracking-[0.12em] text-ivory" style={{ fontWeight: 400 }}>
                LUMIVÈRE
              </span>
            </div>
            <p className="text-sm font-body font-light text-ivory/60 leading-relaxed mb-6">
              Handcrafted floral candles from natural soy wax. Each piece is a living bouquet — sculpted to illuminate extraordinary moments.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="text-ivory/50 hover:text-gold transition-colors duration-300" aria-label="Instagram">
                <Instagram size={18} strokeWidth={1.5} />
              </a>
              <a href="#" className="text-ivory/50 hover:text-gold transition-colors duration-300" aria-label="Facebook">
                <Facebook size={18} strokeWidth={1.5} />
              </a>
              <a href="#" className="text-ivory/50 hover:text-gold transition-colors duration-300" aria-label="YouTube">
                <Youtube size={18} strokeWidth={1.5} />
              </a>
            </div>
          </div>

          {/* Collections */}
          <div>
            <h4 className="text-label text-gold mb-6">Collections</h4>
            <ul className="space-y-3">
              {[
                { href: '/collections/bouquet', label: 'Bouquet Candles' },
                { href: '/collections/zodiac', label: 'Zodiac Crystal' },
                { href: '/collections/seasonal', label: 'Seasonal Editions' },
                { href: '/shop', label: 'The Boutique' },
                { href: '/shop?filter=bestsellers', label: 'Les Favoris' },
                { href: '/shop?filter=new', label: 'Nouvelles Arrivées' },
              ].map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm font-body font-light text-ivory/60 hover:text-ivory transition-colors duration-300">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* La Maison */}
          <div>
            <h4 className="text-label text-gold mb-6">La Maison</h4>
            <ul className="space-y-3">
              {[
                { href: '/about', label: 'Our Story' },
                { href: '/about#craft', label: 'The Craft' },
                { href: '/about#ingredients', label: 'Ingredients' },
                { href: '/journal', label: 'Journal' },
                { href: '/contact', label: 'Contact' },
                { href: '/contact#gifting', label: 'Corporate Gifting' },
              ].map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm font-body font-light text-ivory/60 hover:text-ivory transition-colors duration-300">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Care */}
          <div>
            <h4 className="text-label text-gold mb-6">Customer Care</h4>
            <ul className="space-y-3">
              {[
                { href: '/contact', label: 'Contact Us' },
                { href: '/contact#shipping', label: 'Shipping & Returns' },
                { href: '/contact#faq', label: 'FAQ' },
                { href: '/contact#care', label: 'Candle Care Guide' },
              ].map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm font-body font-light text-ivory/60 hover:text-ivory transition-colors duration-300">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <p className="text-xs text-ivory/40 font-body font-light leading-relaxed">
                Complimentary gift wrapping<br />
                on all orders over €80.<br />
                Free shipping over €120.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Gold Rule */}
      <div className="container">
        <div style={{ height: '1px', background: 'linear-gradient(90deg, transparent, oklch(0.75 0.10 82 / 0.3) 30%, oklch(0.75 0.10 82 / 0.3) 70%, transparent)' }} />
      </div>

      {/* Bottom Section */}
      <div className="container py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs font-body font-light text-ivory/30 tracking-wide">
            © 2024 LUMIVÈRE. All rights reserved. Paris, France.
          </p>
          <div className="flex items-center gap-6">
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map(item => (
              <a key={item} href="#" className="text-xs font-body font-light text-ivory/30 hover:text-ivory/60 transition-colors duration-300">
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
