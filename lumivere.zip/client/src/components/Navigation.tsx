/* LUMIVÈRE Navigation — Parisian Atelier Romantique
   Transparent on hero → ivory on scroll
   Thin gold underline on active links */

import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { ShoppingBag, Menu, X, Search } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';

const navLinks = [
  { href: '/shop', label: 'Shop' },
  { href: '/collections/bouquet', label: 'Bouquets' },
  { href: '/collections/zodiac', label: 'Zodiac' },
  { href: '/about', label: 'La Maison' },
  { href: '/journal', label: 'Journal' },
  { href: '/contact', label: 'Contact' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();
  const { totalItems, toggleCart } = useCart();

  const isHome = location === '/';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const isTransparent = isHome && !scrolled && !mobileOpen;

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
        style={{
          backgroundColor: isTransparent ? 'transparent' : 'oklch(0.975 0.008 85 / 0.96)',
          backdropFilter: isTransparent ? 'none' : 'blur(12px)',
          borderBottom: isTransparent ? 'none' : '1px solid oklch(0.88 0.015 75)',
        }}
      >
        <div className="container">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 group">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-logo-7q7jKznznRE6eJXKwGLwKA.webp"
                alt="LUMIVÈRE"
                className="w-8 h-8 object-contain transition-transform duration-500 group-hover:scale-110"
              />
              <span
                className="font-display text-xl tracking-[0.12em] transition-colors duration-500"
                style={{
                  color: isTransparent ? 'oklch(0.975 0.008 85)' : 'oklch(0.22 0.01 60)',
                  fontWeight: 400,
                }}
              >
                LUMIVÈRE
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`nav-link transition-colors duration-500 ${
                    location === link.href ? 'active' : ''
                  }`}
                  style={{
                    color: isTransparent ? 'oklch(0.975 0.008 85 / 0.85)' : 'oklch(0.35 0.01 60)',
                  }}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Right Icons */}
            <div className="flex items-center gap-4">
              <button
                className="transition-colors duration-300 hover:opacity-70"
                style={{ color: isTransparent ? 'oklch(0.975 0.008 85)' : 'oklch(0.22 0.01 60)' }}
                aria-label="Search"
              >
                <Search size={18} strokeWidth={1.5} />
              </button>

              <button
                onClick={toggleCart}
                className="relative transition-colors duration-300 hover:opacity-70"
                style={{ color: isTransparent ? 'oklch(0.975 0.008 85)' : 'oklch(0.22 0.01 60)' }}
                aria-label="Shopping bag"
              >
                <ShoppingBag size={18} strokeWidth={1.5} />
                {totalItems > 0 && (
                  <span
                    className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-body font-400"
                    style={{
                      backgroundColor: 'oklch(0.75 0.10 82)',
                      color: 'oklch(0.22 0.01 60)',
                    }}
                  >
                    {totalItems}
                  </span>
                )}
              </button>

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="md:hidden transition-colors duration-300"
                style={{ color: isTransparent && !mobileOpen ? 'oklch(0.975 0.008 85)' : 'oklch(0.22 0.01 60)' }}
                aria-label="Menu"
              >
                {mobileOpen ? <X size={20} strokeWidth={1.5} /> : <Menu size={20} strokeWidth={1.5} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className="fixed inset-0 z-40 md:hidden transition-all duration-500"
        style={{
          opacity: mobileOpen ? 1 : 0,
          pointerEvents: mobileOpen ? 'all' : 'none',
          backgroundColor: 'oklch(0.975 0.008 85)',
        }}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8 pt-20">
          {navLinks.map((link, i) => (
            <Link
              key={link.href}
              href={link.href}
              className="font-display text-4xl text-charcoal hover:text-gold transition-colors duration-300"
              style={{
                opacity: mobileOpen ? 1 : 0,
                transform: mobileOpen ? 'translateY(0)' : 'translateY(20px)',
                transition: `opacity 0.5s ease ${i * 0.08}s, transform 0.5s ease ${i * 0.08}s, color 0.3s ease`,
                fontStyle: 'italic',
              }}
            >
              {link.label}
            </Link>
          ))}
          <div
            className="mt-8 flex items-center gap-2"
            style={{
              opacity: mobileOpen ? 1 : 0,
              transition: 'opacity 0.5s ease 0.5s',
            }}
          >
            <div className="gold-rule-short" />
            <span className="text-label text-muted-foreground">Paris · Est. MMXXIV</span>
            <div className="gold-rule-short" />
          </div>
        </div>
      </div>
    </>
  );
}
