export interface Product {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  originalPrice?: number;
  image: string;
  hoverImage?: string;
  collection: 'bouquet' | 'zodiac' | 'seasonal';
  scents: string[];
  sizes: string[];
  description: string;
  details: string[];
  isBestSeller?: boolean;
  isNew?: boolean;
  isLimited?: boolean;
  burnTime?: string;
  weight?: string;
  zodiacSign?: string;
}

export const products: Product[] = [
  // ── BOUQUET COLLECTION ──
  {
    id: 'bouquet-rose-blush',
    name: 'La Rose de Minuit',
    subtitle: 'Blush Garden Rose Bouquet',
    price: 89,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-rose-h5kGVBJnRx8n9jprE2AyMu.webp',
    collection: 'bouquet',
    scents: ['Rose & Oud', 'Jasmine & Musk', 'Unscented'],
    sizes: ['Small (200g)', 'Grande (400g)'],
    description: 'A full garden rose in bloom, sculpted petal by petal from the finest blush soy wax. Light it once and the room remembers.',
    details: ['100% natural soy wax', 'Cotton wick', 'Handcrafted in small batches', 'Burn time: 35–50 hours', 'Diameter: 12cm'],
    isBestSeller: true,
    burnTime: '35–50 hours',
    weight: '400g',
  },
  {
    id: 'bouquet-peony-ivory',
    name: 'Pivoine Éternelle',
    subtitle: 'Ivory Peony Bouquet',
    price: 95,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-peony-YipPMMyqLkerp7Skc6EcHb.webp',
    collection: 'bouquet',
    scents: ['Peony & White Tea', 'Vanilla & Sandalwood', 'Unscented'],
    sizes: ['Small (200g)', 'Grande (400g)'],
    description: 'The peony in full bloom — ivory, lush, and impossibly delicate. Each petal hand-pressed into warm soy wax.',
    details: ['100% natural soy wax', 'Cotton wick', 'Handcrafted in small batches', 'Burn time: 40–55 hours', 'Diameter: 14cm'],
    isBestSeller: true,
    burnTime: '40–55 hours',
    weight: '400g',
  },
  {
    id: 'bouquet-mixed-blush',
    name: 'Le Bouquet de Paris',
    subtitle: 'Mixed Floral Bouquet Collection',
    price: 145,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-bouquet-YNhXUaTMTXaPZbu33LEd4x.webp',
    collection: 'bouquet',
    scents: ['Rose & Jasmine', 'Peony & Musk', 'Unscented'],
    sizes: ['Signature (600g)', 'Grand Luxe (900g)'],
    description: 'A full Parisian bouquet — roses, peonies, ranunculus — sculpted entirely from natural soy wax. The ultimate statement piece.',
    details: ['100% natural soy wax', 'Multiple cotton wicks', 'Handcrafted in small batches', 'Burn time: 60–80 hours', 'Diameter: 20cm'],
    isBestSeller: true,
    burnTime: '60–80 hours',
    weight: '900g',
  },
  {
    id: 'bouquet-dahlia-burgundy',
    name: 'Dahlia Noir',
    subtitle: 'Deep Burgundy Dahlia',
    price: 79,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-product-dahlia-44df2EasezzUDJrMmei8Ma.webp',
    collection: 'bouquet',
    scents: ['Dark Rose & Amber', 'Oud & Vetiver', 'Unscented'],
    sizes: ['Small (200g)', 'Grande (400g)'],
    description: 'Dramatic, architectural, unforgettable. The Dahlia Noir is sculpted from deep burgundy soy wax — a candle that commands the room.',
    details: ['100% natural soy wax', 'Cotton wick', 'Handcrafted in small batches', 'Burn time: 35–50 hours', 'Diameter: 13cm'],
    isNew: true,
    burnTime: '35–50 hours',
    weight: '400g',
  },

  // ── ZODIAC COLLECTION ──
  {
    id: 'zodiac-aries',
    name: 'Bélier',
    subtitle: 'Aries Crystal Candle',
    price: 115,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
    collection: 'zodiac',
    scents: ['Cedarwood & Spice', 'Rose & Pepper', 'Unscented'],
    sizes: ['Signature (350g)'],
    description: 'Born under the fire of Aries. Embedded with carnelian crystals and pressed botanicals, this candle is a ritual and a portrait.',
    details: ['100% natural soy wax', 'Cotton wick', 'Embedded semi-precious crystals', 'Pressed botanicals', 'Burn time: 45–60 hours'],
    isBestSeller: true,
    burnTime: '45–60 hours',
    weight: '350g',
    zodiacSign: 'Aries',
  },
  {
    id: 'zodiac-taurus',
    name: 'Taureau',
    subtitle: 'Taurus Crystal Candle',
    price: 115,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
    collection: 'zodiac',
    scents: ['Rose Quartz & Vanilla', 'Patchouli & Amber', 'Unscented'],
    sizes: ['Signature (350g)'],
    description: 'For the Taurus who surrounds herself in beauty. Rose quartz crystals and dried rose petals embedded in dusty rose wax.',
    details: ['100% natural soy wax', 'Cotton wick', 'Embedded rose quartz crystals', 'Pressed botanicals', 'Burn time: 45–60 hours'],
    burnTime: '45–60 hours',
    weight: '350g',
    zodiacSign: 'Taurus',
  },
  {
    id: 'zodiac-leo',
    name: 'Lion',
    subtitle: 'Leo Crystal Candle',
    price: 115,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
    collection: 'zodiac',
    scents: ['Champagne & Neroli', 'Gold & Amber', 'Unscented'],
    sizes: ['Signature (350g)'],
    description: 'Regal, radiant, unmistakable. The Leo candle is embedded with citrine crystals and gold leaf — a crown in wax.',
    details: ['100% natural soy wax', 'Cotton wick', 'Embedded citrine crystals', 'Gold leaf accents', 'Burn time: 45–60 hours'],
    isNew: true,
    burnTime: '45–60 hours',
    weight: '350g',
    zodiacSign: 'Leo',
  },
  {
    id: 'zodiac-pisces',
    name: 'Poissons',
    subtitle: 'Pisces Crystal Candle',
    price: 115,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
    collection: 'zodiac',
    scents: ['Aquamarine & Sea Salt', 'Jasmine & Moonflower', 'Unscented'],
    sizes: ['Signature (350g)'],
    description: 'Dreamy, intuitive, otherworldly. Aquamarine crystals and moonflower botanicals suspended in translucent blush wax.',
    details: ['100% natural soy wax', 'Cotton wick', 'Embedded aquamarine crystals', 'Dried moonflower', 'Burn time: 45–60 hours'],
    burnTime: '45–60 hours',
    weight: '350g',
    zodiacSign: 'Pisces',
  },

  // ── SEASONAL COLLECTION ──
  {
    id: 'seasonal-autumn',
    name: 'Automne Doré',
    subtitle: 'Autumn Limited Edition',
    price: 135,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-seasonal-NbE5FZrZFzdqPD2644veLD.webp',
    collection: 'seasonal',
    scents: ['Warm Amber & Spice', 'Fig & Sandalwood', 'Unscented'],
    sizes: ['Signature (500g)'],
    description: 'Three flowers of autumn — peony, dahlia, magnolia — sculpted in the season\'s palette. A limited edition that disappears like the leaves.',
    details: ['100% natural soy wax', 'Multiple cotton wicks', 'Seasonal limited edition', 'Burn time: 55–70 hours', 'Gift-ready packaging'],
    isLimited: true,
    burnTime: '55–70 hours',
    weight: '500g',
  },
  {
    id: 'seasonal-atelier',
    name: 'L\'Atelier',
    subtitle: 'The Maison Gift Set',
    price: 195,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-atelier-PvYdNxmoxk9cUa3cf78pNb.webp',
    collection: 'seasonal',
    scents: ['Curated Maison Selection'],
    sizes: ['Gift Set (3 candles)'],
    description: 'The complete LUMIVÈRE experience. Three signature candles, a brass snuffer, and a handwritten note — presented in our signature ivory gift box.',
    details: ['3 signature candles', 'Brass candle snuffer', 'Handwritten gift card', 'Signature ivory gift box', 'Complimentary ribbon'],
    isLimited: true,
    isBestSeller: true,
    burnTime: 'Varies',
    weight: '1.2kg total',
  },
];

export const collections = [
  {
    id: 'bouquet',
    name: 'Bouquet Candles',
    subtitle: 'La Collection Florale',
    description: 'Each candle is a living bouquet — sculpted petal by petal from natural soy wax.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-bouquet-YNhXUaTMTXaPZbu33LEd4x.webp',
    count: 4,
  },
  {
    id: 'zodiac',
    name: 'Zodiac Crystal Candles',
    subtitle: 'La Collection Céleste',
    description: 'Embedded with semi-precious crystals and pressed botanicals. A ritual for every sign.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-zodiac-Erymh4XBtjjM5JZnCvtagu.webp',
    count: 12,
  },
  {
    id: 'seasonal',
    name: 'Seasonal Editions',
    subtitle: 'Éditions Limitées',
    description: 'Created in harmony with the seasons. When they are gone, they are gone.',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663788011626/RnZdv8AtwiggSZgoEirtLb/lumivere-seasonal-NbE5FZrZFzdqPD2644veLD.webp',
    count: 6,
  },
];

export const bestSellers = products.filter(p => p.isBestSeller);
export const newArrivals = products.filter(p => p.isNew);
export const limitedEditions = products.filter(p => p.isLimited);

export function getProductsByCollection(collection: Product['collection']) {
  return products.filter(p => p.collection === collection);
}

export function getProductById(id: string) {
  return products.find(p => p.id === id);
}
